package model;

import java.util.ArrayList;
import java.util.List;

public class Musica {
    private int id;
    private String titulo;
    private String artista;
    private int ano;
    private String tonica;
    private String estilo; // NOVO: Adicionei o atributo estilo
    private List<Acorde> acordes = new ArrayList<>();
    

    public Musica() {
        // Construtor padrão, inicializa atributos
        this.id = 0;
        this.titulo = null;
        this.artista = null;
        this.ano = 0;
        this.tonica = null;
        this.estilo = null; // Inicializar estilo
        this.acordes = new ArrayList<>();
    }
    
    // Construtor original com acordes (ajustado para incluir estilo)
    // Se essa rota for usada para criar músicas, o estilo pode ser null ou padrão
    public Musica(String titulo, String artista, List<Acorde> acordes) {
        this.id = 0;
        this.titulo = titulo;
        this.artista = artista;
        this.acordes = acordes;
        this.ano = 0; // Pode ser alterado depois
        this.tonica = null; // Pode ser alterado depois
        this.estilo = null; // Pode ser alterado depois
    }
    
    // Construtor original com id e acordes (ajustado para incluir estilo)
    public Musica(int id, String titulo, String artista, List<Acorde> acordes) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.acordes = acordes;
        this.ano = 0; // Pode ser alterado depois
        this.tonica = null; // Pode ser alterado depois
        this.estilo = null; // Pode ser alterado depois
    }

    // Construtor existente que agora deve ser **modificado** para incluir 'estilo'
    // Esta é a versão usada por MusicaRepositorioMySQL::extrairMusicaDoResultSet
    public Musica(int id, String titulo, String artista, int ano, String tonica, List<Acorde> acordes) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.ano = ano;
        this.tonica = tonica;
        this.acordes = acordes;
        this.estilo = null; // ESTILO AINDA ESTARIA FALTANDO AQUI! Precisamos de um novo construtor completo.
    }

    // NOVO CONSTRUTOR: Para recuperar dados completos do banco (usado por MusicaRepositorioMySQL)
    public Musica(int id, String titulo, String artista, int ano, String tonica, String estilo, List<Acorde> acordes) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.ano = ano;
        this.tonica = tonica;
        this.estilo = estilo; // Inicializa o estilo
        this.acordes = acordes;
    }

    // Construtor existente para criação sem ID (para o save inicial)
    // Esta é a versão usada por ServicoBusca::criarMusica
    public Musica(String titulo, String artista, int ano, String tonica) {
        this.id = 0; // Garantir que é nova
        this.titulo = titulo;
        this.artista = artista;
        this.ano = ano;
        this.tonica = tonica;
        this.estilo = null; // ESTILO AINDA ESTARIA FALTANDO AQUI! Precisamos de um novo construtor para criação.
        this.acordes = new ArrayList<>();
    }

    // NOVO CONSTRUTOR: Para criar uma nova música com todos os dados, incluindo estilo
    // Usado por ServicoBusca::criarMusica
    public Musica(String titulo, String artista, int ano, String tonica, String estilo) {
        this.id = 0; // Novo objeto, ID 0 indica que ainda não foi persistido
        this.titulo = titulo;
        this.artista = artista;
        this.ano = ano;
        this.tonica = tonica;
        this.estilo = estilo; // Inicializa o estilo
        this.acordes = new ArrayList<>(); // Inicializar vazia
    }
    
    public int getId() {
        return id;
    }

    public void setId(int idMusica) {
        this.id = idMusica;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getTonica() {
        return tonica;
    }

    public void setTonica(String tonica) {
        this.tonica = tonica;
    }

    // NOVO: Getter e Setter para estilo
    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    public List<Acorde> getAcordes() {
        return acordes;
    }

    public void setAcordes(List<Acorde> acordes) {
        this.acordes = acordes;
    }

    @Override
    public String toString() {
        return "Musica{" +
               "id=" + id +
               ", titulo='" + titulo + '\'' +
               ", artista='" + artista + '\'' +
               ", ano=" + ano +
               ", tonica='" + tonica + '\'' +
               ", estilo='" + estilo + '\'' + // NOVO: Incluir estilo no toString
               '}';
    }
}