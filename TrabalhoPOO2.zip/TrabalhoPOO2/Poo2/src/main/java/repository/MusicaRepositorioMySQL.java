package repository;

import model.Musica;
import model.Acorde; 
import controller.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MusicaRepositorioMySQL implements MusicaRepositorio {


    private Musica extrairMusicaDoResultSet(ResultSet rs) throws SQLException {
        int id = rs.getInt("MusicaId");
        String titulo = rs.getString("Titulo");
        String artista = rs.getString("Artista");
        int ano = rs.getInt("Ano");
        String tonica = rs.getString("Tonica");
        String estilo = rs.getString("Estilo"); 

        return new Musica(id, titulo, artista, ano, tonica, estilo, new ArrayList<>()); 
    }

    @Override
    public Musica save(Musica musica) {
        String sql;
        if (musica.getId() == 0) { 
            sql = "INSERT INTO MUSICA (Titulo, Artista, Ano, Tonica, Estilo) VALUES (?, ?, ?, ?, ?)";
        } else { 
            sql = "UPDATE MUSICA SET Titulo = ?, Artista = ?, Ano = ?, Tonica = ?, Estilo = ? WHERE MusicaId = ?";
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, musica.getTitulo());
            stmt.setString(2, musica.getArtista());
            stmt.setInt(3, musica.getAno());
            stmt.setString(4, musica.getTonica());
            stmt.setString(5, musica.getEstilo()); 

            if (musica.getId() != 0) {
                stmt.setInt(6, musica.getId()); 
            }

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0 && musica.getId() == 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        musica.setId(generatedKeys.getInt(1));
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao salvar música no MySQL: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Falha ao salvar música no banco de dados.", e);
        }
        return musica;
    }

    @Override
    public List<Musica> searchByTitleOrArtist(String query) {
        List<Musica> musicas = new ArrayList<>();
        String sql = "SELECT MusicaId, Titulo, Artista, Ano, Tonica, Estilo FROM MUSICA WHERE Titulo LIKE ? OR Artista LIKE ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + query + "%");
            stmt.setString(2, "%" + query + "%");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    musicas.add(extrairMusicaDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar músicas por título ou artista no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return musicas;
    }

    @Override
    public Optional<Musica> findById(int id) {
        String sql = "SELECT MusicaId, Titulo, Artista, Ano, Tonica, Estilo FROM MUSICA WHERE MusicaId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairMusicaDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar música por ID no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.empty();
    }
    
    @Override
    public List<Musica> findAll() {
        List<Musica> musicas = new ArrayList<>();
        String sql = "SELECT MusicaId, Titulo, Artista, Ano, Tonica, Estilo FROM MUSICA";
        try (Connection conn = ConexaoBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                musicas.add(extrairMusicaDoResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todas as músicas no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return musicas;
    }

    @Override
    public void deleteById(int id) {
        String sql = "DELETE FROM MUSICA WHERE MusicaId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Música com ID " + id + " deletada com sucesso.");
            } else {
                System.out.println("Nenhuma música encontrada com ID " + id + " para deletar.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar música por ID no MySQL: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Falha ao deletar música no banco de dados.", e);
        }
    }
}