CREATE TABLE favoritos (
    FavoritoId BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    
    AcordeId INT UNSIGNED NULL,
    
    EscalaId BIGINT UNSIGNED NULL,

    CONSTRAINT fk_favoritos_acorde 
        FOREIGN KEY (AcordeId) REFERENCES acorde(AcordeId)
        ON DELETE CASCADE,

    CONSTRAINT fk_favoritos_escala 
        FOREIGN KEY (EscalaId) REFERENCES escala(EscalaId)
        ON DELETE CASCADE,

    UNIQUE KEY uq_acorde_favorito (AcordeId),
    UNIQUE KEY uq_escala_favorita (EscalaId),

    CONSTRAINT chk_favorito_exclusivo CHECK (
        (CASE WHEN AcordeId IS NOT NULL THEN 1 ELSE 0 END +
         CASE WHEN EscalaId IS NOT NULL THEN 1 ELSE 0 END) <= 1
    )
);