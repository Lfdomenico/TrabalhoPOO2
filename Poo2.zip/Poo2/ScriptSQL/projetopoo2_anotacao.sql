ALTER TABLE anotacao DROP FOREIGN KEY anotacao_ibfk_1;
ALTER TABLE anotacao DROP COLUMN ElementoId;

ALTER TABLE anotacao ADD COLUMN AcordeId INT NULL;
ALTER TABLE anotacao ADD COLUMN EscalaId INT NULL;

ALTER TABLE anotacao ADD CONSTRAINT fk_anotacao_acorde 
    FOREIGN KEY (AcordeId) REFERENCES acorde(AcordeId)
    ON DELETE SET NULL;

ALTER TABLE anotacao ADD CONSTRAINT fk_anotacao_escala 
    FOREIGN KEY (EscalaId) REFERENCES escala(EscalaId)
    ON DELETE SET NULL;