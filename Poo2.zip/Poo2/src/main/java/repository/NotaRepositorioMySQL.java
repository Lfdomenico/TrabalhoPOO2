package repository;

import model.Nota;
import controller.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class NotaRepositorioMySQL implements NotaRepositorio {

    private Nota extrairNotaDoResultSet(ResultSet rs) throws SQLException {
        Nota nota = new Nota();

        int id = rs.getInt("NotaId");
        String nome = rs.getString("Nome");
        String acidente = rs.getString("Acidente");
        int oitava = rs.getInt("Oitava");
        nota.setId(id);
        nota.setNome(nome);
        nota.setAcidente(acidente);
        nota.setOitava(oitava);

        return nota;
    }

    @Override
    public Nota save(Nota nota) {
        String sql;
        if (nota.getId() == 0) { 
            sql = "INSERT INTO NOTA (Nome, Acidente, Oitava) VALUES (?, ?, ?)";
        } else { 
            sql = "UPDATE NOTA SET Nome = ?, Acidente = ?, Oitava = ? WHERE NotaId = ?";
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, nota.getNome());

            if (nota.getAcidente() == null || nota.getAcidente().isEmpty()) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, nota.getAcidente());
            }

            stmt.setInt(3, nota.getOitava());

            if (nota.getId() != 0) {
                stmt.setInt(4, nota.getId()); 
            }

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0 && nota.getId() == 0) { 
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        nota.setId(generatedKeys.getInt(1)); 
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao salvar nota no MySQL: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Falha ao salvar nota no banco de dados.", e);
        }
        return nota;
    }

    @Override
    public Optional<Nota> findById(int id) {
        String sql = "SELECT NotaId, Nome, Acidente, Oitava FROM NOTA WHERE NotaId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairNotaDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar nota por ID no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public List<Nota> findAll() {
        List<Nota> notas = new ArrayList<>();
        String sql = "SELECT NotaId, Nome, Acidente, Oitava FROM NOTA";
        try (Connection conn = ConexaoBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                notas.add(extrairNotaDoResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todas as notas no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return notas;
    }

    @Override
    public Optional<Nota> findByNomeCompleto(String nomeCompleto) {
   
       
        String nome = null;
        String acidente = null;
        int oitava = -1;

        String tempNome = nomeCompleto;
        String tempAcidente = null;
        int tempOitava = -1;

        try {
  
            tempOitava = Integer.parseInt(tempNome.substring(tempNome.length() - 1));
            tempNome = tempNome.substring(0, tempNome.length() - 1); 
        } catch (NumberFormatException e) {
          
            return Optional.empty(); 
        }

        if (tempNome.endsWith("#")) {
            tempAcidente = "#";
            nome = tempNome.substring(0, tempNome.length() - 1);
        } else if (tempNome.endsWith("b")) {
            tempAcidente = "b";
            nome = tempNome.substring(0, tempNome.length() - 1);
        } else if (tempNome.endsWith("##")) { 
            tempAcidente = "##";
            nome = tempNome.substring(0, tempNome.length() - 2);
        } else if (tempNome.endsWith("bb")) { 
            tempAcidente = "bb";
            nome = tempNome.substring(0, tempNome.length() - 2);
        } else {
            nome = tempNome; 
        }

        if (nome == null || nome.isEmpty() || tempOitava == -1) {
            return Optional.empty();
        }

        String sql = "SELECT NotaId, Nome, Acidente, Oitava FROM NOTA WHERE Nome = ? AND Oitava = ?";
        if (tempAcidente == null || tempAcidente.isEmpty()) {
            sql += " AND Acidente IS NULL";
        } else {
            sql += " AND Acidente = ?";
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setInt(2, tempOitava);
            if (tempAcidente != null && !tempAcidente.isEmpty()) {
                stmt.setString(3, tempAcidente);
            }

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairNotaDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar nota por nome completo no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.empty();
    }
    
    public Optional<Nota> findByComponentes(String nome, String acidente, int oitava) {
        StringBuilder sql = new StringBuilder("SELECT * FROM nota WHERE Nome = ? AND Oitava = ?");

        if (acidente == null || acidente.isEmpty()) {
            sql.append(" AND Acidente IS NULL");
        } else {
            sql.append(" AND Acidente = ?");
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            stmt.setString(1, nome);
            stmt.setInt(2, oitava);
            if (acidente != null && !acidente.isEmpty()) {
                stmt.setString(3, acidente);
            }

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairNotaDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar nota por componentes: " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.empty();
    }
}