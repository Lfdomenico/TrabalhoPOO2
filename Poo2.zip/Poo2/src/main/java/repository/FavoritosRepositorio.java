package repository;

import model.ElementoMusical;
import java.util.List;

public interface FavoritosRepositorio {
    void adicionar(ElementoMusical elemento);

    void remover(ElementoMusical elemento);

    boolean ehFavorito(ElementoMusical elemento);

    List<Integer> listarIdsDeAcordesFavoritos();

    List<Long> listarIdsDeEscalasFavoritas();
}