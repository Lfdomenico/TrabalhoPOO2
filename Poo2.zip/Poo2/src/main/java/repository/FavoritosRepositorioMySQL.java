package repository;

import controller.ConexaoBD;
import model.Acorde;
import model.ElementoMusical;
import model.Escala;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FavoritosRepositorioMySQL implements FavoritosRepositorio {

    @Override
    public void adicionar(ElementoMusical elemento) {
        if (elemento == null || elemento.getId() == 0) return;

        String sql = "";
        if (elemento instanceof Acorde) {
            sql = "INSERT IGNORE INTO favoritos (AcordeId) VALUES (?)";
        } else if (elemento instanceof Escala) {
            sql = "INSERT IGNORE INTO favoritos (EscalaId) VALUES (?)";
        } else {
            return;
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, elemento.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar favorito", e);
        }
    }

    @Override
    public void remover(ElementoMusical elemento) {
        if (elemento == null || elemento.getId() == 0) return;

        String sql = "";
        if (elemento instanceof Acorde) {
            sql = "DELETE FROM favoritos WHERE AcordeId = ?";
        } else if (elemento instanceof Escala) {
            sql = "DELETE FROM favoritos WHERE EscalaId = ?";
        } else {
            return;
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, elemento.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao remover favorito", e);
        }
    }

    @Override
    public boolean ehFavorito(ElementoMusical elemento) {
        if (elemento == null || elemento.getId() == 0) return false;

        String sql = "";
        if (elemento instanceof Acorde) {
            sql = "SELECT COUNT(*) FROM favoritos WHERE AcordeId = ?";
        } else if (elemento instanceof Escala) {
            sql = "SELECT COUNT(*) FROM favoritos WHERE EscalaId = ?";
        } else {
            return false;
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, elemento.getId());

            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar favorito", e);
        }
    }

    @Override
    public List<Integer> listarIdsDeAcordesFavoritos() {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT AcordeId FROM favoritos WHERE AcordeId IS NOT NULL";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                ids.add(rs.getInt("AcordeId"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar IDs de acordes favoritos", e);
        }
        return ids;
    }

    @Override
    public List<Long> listarIdsDeEscalasFavoritas() {
        List<Long> ids = new ArrayList<>();
        String sql = "SELECT EscalaId FROM favoritos WHERE EscalaId IS NOT NULL";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                ids.add(rs.getLong("EscalaId"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar IDs de escalas favoritas", e);
        }
        return ids;
    }
}