package repository;

import model.Musica;
import java.util.List;
import java.util.Optional;

public interface MusicaRepositorio {

    //teste
    Musica save(Musica musica);
    
    //busca pelo titulo ou artista
    List<Musica> searchByTitleOrArtist(String query);

    Optional<Musica> findById(int id);  

    List<Musica> findAll();

    void deleteById(int id);
}