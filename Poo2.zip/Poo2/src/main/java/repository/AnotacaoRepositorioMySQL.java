package repository;

import model.Anotacao;
import model.ElementoMusical; 
import controller.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import model.Acorde;
import model.Escala;

public class AnotacaoRepositorioMySQL implements AnotacaoRepositorio {

    private final AcordeRepositorio acordeRepo;
    private final EscalaRepositorio escalaRepo;

    public AnotacaoRepositorioMySQL(AcordeRepositorio acordeRepo, EscalaRepositorio escalaRepo) {
        this.acordeRepo = acordeRepo;
        this.escalaRepo = escalaRepo;
    }

    private Anotacao extrairAnotacaoDoResultSet(ResultSet rs) throws SQLException {
        int id = rs.getInt("AnotacaoId");
        String texto = rs.getString("Texto");

        ElementoMusical elementoMusical = null;

        int acordeId = rs.getInt("AcordeId");
        if (!rs.wasNull()) {
            elementoMusical = acordeRepo.findById(acordeId).orElse(null);
        } else {
            int escalaId = rs.getInt("EscalaId");
            if (!rs.wasNull()) {
                elementoMusical = escalaRepo.findById(escalaId).orElse(null);
            }
        }

        return new Anotacao(id, texto, elementoMusical);
    }

    @Override
    public Anotacao save(Anotacao anotacao) {
        String sql;
        Integer acordeId = null;
        Integer escalaId = null;
        ElementoMusical elemento = anotacao.getElementoSobre();

        if (elemento instanceof Acorde) {
            acordeId = elemento.getId();
        } else if (elemento instanceof Escala) {
            escalaId = elemento.getId();
        }

        if (anotacao.getId() == 0) {
            sql = "INSERT INTO anotacao (Texto, AcordeId, EscalaId) VALUES (?, ?, ?)";
        } else {
            sql = "UPDATE anotacao SET Texto = ?, AcordeId = ?, EscalaId = ? WHERE AnotacaoId = ?";
        }

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, anotacao.getTexto());

            if (acordeId != null) {
                stmt.setInt(2, acordeId);
            } else {
                stmt.setNull(2, java.sql.Types.INTEGER);
            }

            if (escalaId != null) {
                stmt.setInt(3, escalaId);
            } else {
                stmt.setNull(3, java.sql.Types.INTEGER);
            }

            if (anotacao.getId() != 0) {
                stmt.setInt(4, anotacao.getId());
            }

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0 && anotacao.getId() == 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        anotacao.setId(generatedKeys.getInt(1));
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao salvar anotação no MySQL: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Falha ao salvar anotação no banco de dados.", e);
        }
        return anotacao;
    }

    @Override
    public Optional<Anotacao> findById(int id) {
        String sql = "SELECT AnotacaoId, Texto, AcordeId, EscalaId FROM anotacao WHERE AnotacaoId = ?";
        
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairAnotacaoDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar anotação por ID no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public List<Anotacao> findByElementoId(int idElemento) {
        List<Anotacao> anotacoes = new ArrayList<>();
        String sql = "SELECT AnotacaoId, Texto, AcordeId, EscalaId FROM anotacao WHERE AcordeId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idElemento);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    anotacoes.add(extrairAnotacaoDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar anotações por AcordeId no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return anotacoes;
    }

    @Override
    public List<Anotacao> findAll() {
        List<Anotacao> anotacoes = new ArrayList<>();
        String sql = "SELECT AnotacaoId, Texto, AcordeId, EscalaId FROM anotacao";
        try (Connection conn = ConexaoBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                anotacoes.add(extrairAnotacaoDoResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todas as anotações no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return anotacoes;
    }

    @Override
    public void deleteById(int id) {
        String sql = "DELETE FROM anotacao WHERE AnotacaoId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Erro ao deletar anotação por ID no MySQL: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Falha ao deletar anotação no banco de dados.", e);
        }
    }
}