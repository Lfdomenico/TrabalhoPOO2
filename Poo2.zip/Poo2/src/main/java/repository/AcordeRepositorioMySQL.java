package repository;

import model.Acorde;
import model.Nota;
import controller.ConexaoBD; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class AcordeRepositorioMySQL implements AcordeRepositorio {
    
    private final NotaRepositorio notaRepositorio;
    
    public AcordeRepositorioMySQL(NotaRepositorio notaRepositorio) {
        this.notaRepositorio = notaRepositorio;
    }

    private Acorde extrairAcordeDoResultSet(ResultSet rs) throws SQLException {
        Acorde acorde = new Acorde();

        int acordeId = rs.getInt("AcordeId");
        acorde.setId(acordeId);
        acorde.setNome(rs.getString("nome"));
        acorde.setTipo(rs.getString("tipo"));

        int tonicaId = rs.getInt("TonicaId");
        if (tonicaId > 0) {
            notaRepositorio.findById(tonicaId).ifPresent(acorde::setTonica);
        }
        
        String estruturaNotasStr = rs.getString("EstruturaNotas");
        List<Nota> notasDoAcorde = carregarNotasPelaEstrutura(estruturaNotasStr);
        acorde.setNotas(notasDoAcorde);

        System.out.println(">>> Acorde ID " + acordeId + " carregado com " + notasDoAcorde.size() + " notas.");
        return acorde;
    }
    
    private List<Nota> carregarNotasPelaEstrutura(String estruturaNotas) {
    List<Nota> notas = new ArrayList<>();
    if (estruturaNotas == null || estruturaNotas.trim().isEmpty()) {
        return notas;
    }

    final int OITAVA_PADRAO = 1;

    String[] nomesDasNotas = estruturaNotas.split("\\s*-\\s*");

    for (String nomeCompleto : nomesDasNotas) {
        String nomeBase;
        String acidente = null;

        if (nomeCompleto.endsWith("#")) {
            nomeBase = nomeCompleto.substring(0, nomeCompleto.length() - 1);
            acidente = "#";
        } else if (nomeCompleto.endsWith("b")) {
            nomeBase = nomeCompleto.substring(0, nomeCompleto.length() - 1);
            acidente = "b";
        } else {
            nomeBase = nomeCompleto;
        }
        
        Optional<Nota> notaEncontrada = notaRepositorio.findByComponentes(nomeBase, acidente, OITAVA_PADRAO);
        
        if (notaEncontrada.isPresent()) {
            notas.add(notaEncontrada.get());
        }
    }
    return notas;
}

    @Override
    public Acorde save(Acorde acorde) {
        if (acorde.getId() != 0) {
            System.err.println("O UPDATE ainda não foi feito para a tabela dupla.");
            return acorde;
        }

        String sqlElemento = "INSERT INTO elementomusical (Nome, InfoAdicional) VALUES (?, ?)";
        String sqlAcorde = "INSERT INTO acorde (AcordeId, Nome, Tipo, TonicaId, EstruturaNotas) VALUES (?, ?, ?, ?, ?)";

        Connection conn = null;
        try {
            conn = ConexaoBD.getConnection();
            conn.setAutoCommit(false); 

            try (PreparedStatement stmtElemento = conn.prepareStatement(sqlElemento, Statement.RETURN_GENERATED_KEYS)) {
                stmtElemento.setString(1, acorde.getNome());
                stmtElemento.setString(2, acorde.getInfoComplementar());
                stmtElemento.executeUpdate();

                try (ResultSet generatedKeys = stmtElemento.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        acorde.setId(generatedKeys.getInt(1));
                    } else {
                        throw new SQLException("Falha ao criar ElementoMusical, nenhum ID obtido.");
                    }
                }
            }

            try (PreparedStatement stmtAcorde = conn.prepareStatement(sqlAcorde)) {
                stmtAcorde.setInt(1, acorde.getId()); 
                stmtAcorde.setString(2, acorde.getNome());
                stmtAcorde.setString(3, acorde.getTipo());

                Integer tonicaId = (acorde.getTonica() != null) ? acorde.getTonica().getId() : null;
                if (tonicaId == null) {
                    stmtAcorde.setNull(4, java.sql.Types.INTEGER);
                } else {
                    stmtAcorde.setInt(4, tonicaId);
                }

                String estruturaNotasStr = acorde.getNotas().stream().map(Nota::getNome).collect(Collectors.joining("-"));
                stmtAcorde.setString(5, estruturaNotasStr);

                stmtAcorde.executeUpdate();
            }

            // Se tudo deu certo, efetiva a transação
            conn.commit();
            System.out.println("Acorde e ElementoMusical salvos com sucesso na transação.");

        } catch (SQLException e) {
            System.err.println("Erro na transação ao salvar Acorde. Realizando rollback.");
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback(); // Desfaz qualquer alteração se ocorrer um erro
                } catch (SQLException ex) {
                    System.err.println("Erro ao realizar rollback: " + ex.getMessage());
                }
            }
            throw new RuntimeException("Falha ao salvar acorde no banco de dados.", e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true); // Restaura o modo auto-commit
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return acorde;
    }

    @Override
    public Optional<Acorde> findById(int id) {
        String sql = "SELECT * FROM acorde WHERE AcordeId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairAcordeDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    public Optional<Acorde> findByNomeAndTipo(String nome, String tipo) {
        String sql = "SELECT AcordeId, Nome, Tipo, TonicaId, EstruturaNotas FROM acorde WHERE Nome = ? AND Tipo = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setString(2, tipo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairAcordeDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar acorde por Nome e Tipo no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public List<Acorde> findByNameContaining(String nome) {
        List<Acorde> acordes = new ArrayList<>();
        String sql = "SELECT AcordeId, Nome, Tipo, TonicaId, EstruturaNotas FROM acorde WHERE Nome LIKE ? OR Tipo LIKE ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + nome + "%");
            stmt.setString(2, "%" + nome + "%");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    acordes.add(extrairAcordeDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar acordes por nome no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return acordes;
    }
    
    @Override
    public List<Acorde> findByTonica(Nota tonica) {
        List<Acorde> acordes = new ArrayList<>();
        String sql = "SELECT AcordeId, Nome, Tipo, TonicaId, EstruturaNotas FROM acorde WHERE TonicaId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, tonica.getId()); 
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    acordes.add(extrairAcordeDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar acordes por Tonica no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return acordes;
    }

    @Override
    public List<Acorde> findByTipo(String tipo) {
        List<Acorde> acordes = new ArrayList<>();
        String sql = "SELECT AcordeId, Nome, Tipo, TonicaId, EstruturaNotas FROM acorde WHERE Tipo = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, tipo);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    acordes.add(extrairAcordeDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar acordes por Tipo no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return acordes;
    }

    @Override
    public List<String> findAllTipos() {
        List<String> tipos = new ArrayList<>();
        String sql = "SELECT DISTINCT Tipo FROM acorde ORDER BY Tipo"; 
        try (Connection conn = ConexaoBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                tipos.add(rs.getString("Tipo"));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todos os tipos de acordes no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return tipos;
    }


    @Override
    public List<Acorde> findAll() {
        List<Acorde> todosOsAcordes = new ArrayList<>();
        String sql = "SELECT * FROM acorde";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while(rs.next()) {
                todosOsAcordes.add(extrairAcordeDoResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return todosOsAcordes;
    }

    @Override
    public void deleteById(int id) {
        String sql = "DELETE FROM acorde WHERE AcordeId = ?";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Acorde com ID " + id + " deletado com sucesso.");
            } else {
                System.out.println("Nenhum acorde encontrado com ID " + id + " para deletar.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar acorde por ID no MySQL: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Falha ao deletar acorde no banco de dados.", e);
        }
    }

    @Override
    public Optional<Acorde> buscarPorNome(String nomeAcorde) {
        String sql = "SELECT * FROM acorde WHERE Nome = ?";

        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nomeAcorde);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(extrairAcordeDoResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar acorde por nome exato no MySQL: " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.empty();
    }
    
     private List<Nota> carregarNotasDoAcorde(int acordeId) {
        List<Nota> notas = new ArrayList<>();
        String sql = "SELECT NotaId FROM acorde_notas WHERE AcordeId = ?";
        
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, acordeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int notaId = rs.getInt("NotaId");
                    notaRepositorio.findById(notaId).ifPresent(notas::add);
                }
            }
        } catch (SQLException e) {
            System.err.println("ERRO: Falha ao carregar a lista de notas para o acorde ID " + acordeId);
            e.printStackTrace();
        }
        return notas;
    }
}