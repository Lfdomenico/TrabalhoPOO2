package repository;

import model.Escala;
import java.util.List;
import java.util.Optional;

public interface EscalaRepositorio {

    //teste
    Escala save(Escala escala);

    Optional<Escala> findById(int id);

    List<Escala> findByEstrutura(String estrutura);

    List<Escala> findByNameContaining(String nome);

    Optional<Escala> findByNome(String nome);

    Optional<String> findEstruturaByNome(String nome);

    List<Escala> findAll();
    
    Optional<Escala> findByNomeAndTipo(String nome, String tipo);

    void deleteById(int id);
}