package model;

import java.util.List;

public interface IElementoSonoro {
    List<Nota> getNotas();
}
