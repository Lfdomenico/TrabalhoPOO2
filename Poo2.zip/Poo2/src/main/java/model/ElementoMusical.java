package model;

import java.util.Objects;

public abstract class ElementoMusical{
    protected int id;
    protected String nome;
    protected String infoAdicional;

    public ElementoMusical() {
    }

    public ElementoMusical(String nome) {
        this.nome = nome;
    }
    
    public ElementoMusical(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getInfoAdicional() {
        return infoAdicional;
    }

    public void setInfoAdicional(String infoAdicional) {
        this.infoAdicional = infoAdicional;
    }
    
    public abstract String getInfoComplementar();
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        
        if (o == null || getClass() != o.getClass()) return false;
        
        ElementoMusical that = (ElementoMusical) o;
        return this.id != 0 && this.id == that.id;
    }
    
    @Override
    public int hashCode() {
        return id != 0 ? Objects.hash(id) : super.hashCode();
    }
}
