package controller;

import service.ServicoBusca;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional; 
import model.Acorde;
import model.Escala;
import model.Nota;

public class ControladorBusca {

    public final ServicoBusca servicoBusca;

    public ControladorBusca(ServicoBusca servicoBusca) {
        this.servicoBusca = servicoBusca;
    }

    public List<?> realizarBusca(Map<String, String> filtros) {
        if (filtros == null || !filtros.containsKey("tipo")) {
            System.err.println("CONTROLLER: Erro - O tipo da busca não foi especificado nos filtros.");
            return Collections.emptyList();
        }

        String tipoBusca = filtros.get("tipo");
        try {
            switch (tipoBusca.toLowerCase()) {
               case "acorde":
                if (filtros.containsKey("nome") && filtros.containsKey("tipoAcorde")) {
                    String nome = filtros.get("nome");
                    String tipo = filtros.get("tipoAcorde");
                    Optional<Acorde> acordeOpt = servicoBusca.buscarAcordePorNomeETipo(nome, tipo);
                    return acordeOpt.map(Collections::singletonList).orElse(Collections.emptyList());
                } else if (filtros.containsKey("nomeContendo")) {
                    String nome = filtros.get("nomeContendo");
                    return servicoBusca.buscarAcordesPorNomeContendo(nome);
                } else if (filtros.containsKey("id")) {
                    return Collections.emptyList();
                } else {
                    throw new IllegalArgumentException("Filtros de busca para acorde inválidos");
                }
                
                case "escala":
                    if (filtros.containsKey("id")) {
                        int idEscala = Integer.parseInt(filtros.get("id"));
                        return Collections.singletonList(servicoBusca.buscarEscala(idEscala));
                    } else if (filtros.containsKey("nome")) {
                        String nomeEscala = filtros.get("nome");
                        return servicoBusca.buscarEscalaPorNome(nomeEscala);
                    } else {
                        throw new IllegalArgumentException("Filtro de busca para escala inválido");
                    }

                case "entidademusical":
                    if (!filtros.containsKey("id")) {
                        throw new IllegalArgumentException("ID da entidade musical não fornecido");
                    }
                    int idEntidade = Integer.parseInt(filtros.get("id"));
                    return Collections.singletonList(servicoBusca.buscarEntidadeMusical(idEntidade));

                case "musica":
                    if (!filtros.containsKey("query")) {
                        throw new IllegalArgumentException("Termo de busca não fornecido");
                    }
                    String query = filtros.get("query");
                    return servicoBusca.buscarMusica(query);
                case "nota":
                    if (!filtros.containsKey("nomeCompleto")) {
                        throw new IllegalArgumentException("Termo de busca não fornecido");
                    }
                    String nomeCompleto = filtros.get("nomeCompleto");

                    Optional<Nota> notaOpt = servicoBusca.buscarNotaPorNomeCompleto(nomeCompleto);
                    return notaOpt.map(notaEncontrada -> Collections.singletonList(notaEncontrada)).orElse(Collections.emptyList());
                case "progressao":
                    if (!filtros.containsKey("nome")) {
                        throw new IllegalArgumentException("Termo de busca não fornecido");
                    }
                    String nomeProgressao = filtros.get("nome");
                    return servicoBusca.buscarProgressoesPorNome(nomeProgressao);
                default:
                    System.err.println("CONTROLLER: Tipo de busca desconhecido: '" + tipoBusca + "'");
                    return Collections.emptyList();
            }
        } catch (NumberFormatException e) {
            System.err.println("CONTROLLER: Erro - O ID fornecido para a busca não é um número válido. Detalhe: " + e.getMessage());
            return Collections.emptyList();
        } catch (IllegalArgumentException e) {
            System.err.println("CONTROLLER: Erro nos filtros de busca: " + e.getMessage());
            return Collections.emptyList();
        } catch (RuntimeException e) {
            System.err.println("CONTROLLER: Erro durante a busca: " + e.getMessage());
            return Collections.emptyList();
        }
    }
    
    public Optional<Acorde> lidarComTrocaDeTipoDeAcorde(Acorde acordeOriginal) {
        if (acordeOriginal == null || acordeOriginal.getNome() == null || acordeOriginal.getTipo() == null) {
            return Optional.empty();
        }

        String tipoOriginal = acordeOriginal.getTipo();
        String tipoAlvo = "Maior".equalsIgnoreCase(tipoOriginal) ? "Menor" : "Maior";

        return servicoBusca.buscarAcordePorNomeETipo(acordeOriginal.getNome(), tipoAlvo);
    }
    
    public Optional<Escala> lidarComTrocaDeTipoDeEscala(Escala escalaOriginal) {
        if (escalaOriginal == null || escalaOriginal.getNome() == null || escalaOriginal.getTipo() == null) {
            return Optional.empty();
        }

        String nomeOriginal = escalaOriginal.getNome();
        String tipoOriginal = escalaOriginal.getTipo();

        String tipoAlvo;
        String nomeAlvo;

        if ("Maior".equalsIgnoreCase(tipoOriginal)) {
            tipoAlvo = "Menor";
            nomeAlvo = nomeOriginal + "m";
        } else if ("Menor".equalsIgnoreCase(tipoOriginal)) {
            tipoAlvo = "Maior";
            if (nomeOriginal.toLowerCase().endsWith("m")) {
                nomeAlvo = nomeOriginal.substring(0, nomeOriginal.length() - 1);
            } else {
                System.err.println("CONTROLLER BUSCA: A escala Menor '" + nomeOriginal + "' não termina em 'm'). Não é possível encontrar a escala Maior correspondente automaticamente.");
                return Optional.empty();
            }
        } else {
            return Optional.empty();
        }

        System.out.println("CONTROLLER BUSCA: Buscando por escala com nome '" + nomeAlvo + "' e tipo '" + tipoAlvo + "'");

        return servicoBusca.buscarEscalaPorNomeETipo(nomeAlvo, tipoAlvo);
    }
}