package controller;

import model.Progressao;
import service.ServicoProgressao;
import java.io.IOException;

public class ControladorProgressao {

    private final ServicoProgressao servicoProgressao;

    public ControladorProgressao(ServicoProgressao servicoProgressao) {
        this.servicoProgressao = servicoProgressao;
    }

    public Progressao lidarComCriacao(String nome) {
        try {
            Progressao novaProgressao = servicoProgressao.criarProgressao(nome);
            return novaProgressao;
        } catch (IllegalArgumentException e) {
            System.err.println("CONTROLLER: Erro ao criar progressão: " + e.getMessage());
            return null;
        }
    }

    public void lidarComAdicaoAcorde(int idProgressao, int idAcorde, int posicao) {
        try {
            servicoProgressao.adicionarAcorde(idProgressao, idAcorde, posicao);
        } catch (RuntimeException e) {
            System.err.println("CONTROLLER: Erro! " + e.getMessage() + ". Exibindo mensagem de erro");
        }
    }

    public void lidarComRenomeacao(int idProgressao, String novoNome) {
        try {
            servicoProgressao.renomearProgressao(idProgressao, novoNome);
        } catch (RuntimeException e) {
            System.err.println("CONTROLLER: Erro! " + e.getMessage());
        }
    }

    public void lidarComExclusao(int idProgressao) {
        try {
            servicoProgressao.excluirProgressao(idProgressao);
        } catch (RuntimeException e) {
            System.err.println("CONTROLLER: Erro! " + e.getMessage());
        }
    }

    public String lidarComExportacao(int idProgressao) {
        try {
            String dadosCsv = servicoProgressao.exportarProgressao(idProgressao);
            return dadosCsv;
        } catch (Exception e) {
            System.err.println("CONTROLLER: Erro ao exportar progressão: " + e.getMessage());
            return null;
        }
    }

    public Progressao lidarComImportacao(String nomeNovaProgressao, String dadosCsv) {
        try {
            Progressao progressaoImportada = servicoProgressao.importarProgressao(nomeNovaProgressao, dadosCsv);
            System.out.println("CONTROLLER: Progressão importada com ID " + progressaoImportada.getId());
            return progressaoImportada;
        } catch (Exception e) {
            System.err.println("CONTROLLER: Erro ao importar progressão: " + e.getMessage());
            return null;
        }
    }
    
    public void lidarComExportacaoParaArquivo(int idProgressao, String caminhoArquivo) {
        try {
            servicoProgressao.exportarParaArquivo(idProgressao, caminhoArquivo);
            System.out.println("CONTROLLER: Arquivo de exportação gerado.");
        } catch (IOException e) {
            System.err.println("CONTROLLER: Erro de arquivo! Não foi possível escrever em " + caminhoArquivo);
        } catch (RuntimeException e) {
            System.err.println("CONTROLLER: Erro! " + e.getMessage());
        }
    }
    
    public void lidarComImportacaoDeArquivo(String nomeProgressao, String caminhoArquivo) {
        try {
            Progressao p = servicoProgressao.importarDeArquivo(nomeProgressao, caminhoArquivo);
            System.out.println("CONTROLLER: Progressão importada com ID: " + p.getId());
        } catch (IOException e) {
            System.err.println("CONTROLLER: Erro de arquivo! Não foi possível ler de " + caminhoArquivo);
        } catch (RuntimeException e) {
            System.err.println("CONTROLLER: Erro! " + e.getMessage());
        }
    }
    
    public Progressao lidarComAdicaoAcorde(int idProgressao, int idAcorde) {
        try {
            return servicoProgressao.adicionarAcorde(idProgressao, idAcorde);
        } catch (Exception e) {
            System.err.println("CONTROLLER: Erro ao adicionar acorde: " + e.getMessage());
            return null;
        }
    }
    
    public Progressao lidarComRemocaoDeAcorde(int idProgressao, int posicao) {
        try {
            return servicoProgressao.removerAcorde(idProgressao, posicao);
        } catch (Exception e) {
            System.err.println("CONTROLLER: Erro ao remover acorde: " + e.getMessage());
            return null;
        }
    }
    
    public Progressao lidarComSalvar(Progressao progressaoParaSalvar) {
        if (progressaoParaSalvar == null) {
            System.err.println("CONTROLLER: Tentativa de salvar uma progressão nula.");
            throw new IllegalArgumentException("A progressão para salvar não pode ser nula.");
        }

        return servicoProgressao.salvarProgressao(progressaoParaSalvar);
    }
}