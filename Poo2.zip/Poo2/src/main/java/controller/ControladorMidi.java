package controller;

import service.ServicoAudio;
import service.ServicoMidi;
import javax.sound.midi.MidiDevice;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import model.Nota;

public class ControladorMidi {

    private final ServicoMidi servicoMidi;
    private final ServicoAudio servicoAudio;

    public ControladorMidi(ServicoMidi servicoMidi, ServicoAudio servicoAudio) {
        this.servicoMidi = servicoMidi;
        this.servicoAudio = servicoAudio;
    }

    public void iniciarMonitoramento() { //pra testes
        Map<String, MidiDevice.Info> dispositivos = servicoMidi.listarDispositivosDeEntrada();
        if (dispositivos.isEmpty()) {
            return;
        }
        MidiDevice.Info primeiro = dispositivos.values().iterator().next();
        if (servicoMidi.conectarDispositivo(primeiro)) {
            servicoMidi.onNotaRecebida(servicoAudio::pressionarNota);
            servicoMidi.onNotaFinalizada((nota, duracao) -> servicoAudio.soltarNota(nota));
            System.out.println("CONTROLLER MIDI: Monitoramento ativo.");
        }
    }

    public void pararMonitoramento() { //pra testes
        System.out.println("CONTROLLER MIDI: Parando monitoramento...");
        servicoMidi.close();
    }
    
    public boolean iniciarMonitoramentoComCallbacks(Consumer<Nota> onNotaPressionadaView, BiConsumer<Nota, Long> onNotaSoltaView) {
        System.out.println("CONTROLLER MIDI: Iniciando monitoramento com callbacks para a GUI...");
        Map<String, MidiDevice.Info> dispositivos = servicoMidi.listarDispositivosDeEntrada();
        if (dispositivos.isEmpty()) {
            System.out.println("CONTROLLER MIDI: Nenhum dispositivo encontrado.");
            return false;
        }

        MidiDevice.Info primeiroDispositivo = dispositivos.values().iterator().next();
        if (servicoMidi.conectarDispositivo(primeiroDispositivo)) {
            servicoMidi.onNotaRecebida(onNotaPressionadaView.andThen(servicoAudio::pressionarNota)
            );
            servicoMidi.onNotaFinalizada((nota, duracao) -> {onNotaSoltaView.accept(nota, duracao);servicoAudio.soltarNota(nota);});
            
            System.out.println("CONTROLLER MIDI: Monitoramento ativo com callbacks para GUI e Áudio.");
            return true;
        }
        return false;
    }
}