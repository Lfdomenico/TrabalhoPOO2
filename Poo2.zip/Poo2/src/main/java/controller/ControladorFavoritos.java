package controller;

import model.ElementoMusical;
import service.ServicoBusca;
import service.ServicoFavoritos;

public class ControladorFavoritos {

    private final ServicoFavoritos servicoFavoritos;
    private final ServicoBusca servicoBusca;

    public ControladorFavoritos(ServicoFavoritos servicoFavoritos, ServicoBusca servicoBusca) {
        this.servicoFavoritos = servicoFavoritos;
        this.servicoBusca = servicoBusca;
    }

    public void lidarComToggleFavorito(ElementoMusical elemento) {
    if (elemento == null) return;
    
    try {
        if (servicoFavoritos.ehFavorito(elemento)) {
            servicoFavoritos.removerFavorito(elemento);
            System.out.println("CONTROLLER: Removido dos favoritos: " + elemento.getNome());
        } else {
            servicoFavoritos.adicionarFavorito(elemento);
            System.out.println("CONTROLLER: Adicionado aos favoritos: " + elemento.getNome());
        }
    } catch (RuntimeException e) {
        System.err.println("CONTROLLER FAVORITOS: Erro - " + e.getMessage());
    }
}
    
    public boolean ehFavorito(ElementoMusical elemento) {
        if (elemento == null) {
            return false;
        }
        return servicoFavoritos.ehFavorito(elemento);
    }
}