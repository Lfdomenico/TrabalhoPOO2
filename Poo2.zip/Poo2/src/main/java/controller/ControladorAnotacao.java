package controller;

import java.util.Optional;
import model.Anotacao;
import model.ElementoMusical;
import service.ServicoAnotacao;
import service.ServicoBusca;

public class ControladorAnotacao {

    private final ServicoAnotacao servicoAnotacao;
    private final ServicoBusca servicoBusca;
    
    public ControladorAnotacao(ServicoAnotacao servicoAnotacao, ServicoBusca servicoBusca) {
        this.servicoAnotacao = servicoAnotacao;
        this.servicoBusca = servicoBusca;
    }

    public Anotacao lidarComCriacao(String texto) {
        try {
            Anotacao novaAnotacao = servicoAnotacao.criarAnotacao(texto);
            return novaAnotacao;
        } catch (Exception e) {
            System.err.println("CONTROLLER ANOTAÇÃO: Erro - " + e.getMessage());
            return null;
        }
    }

    public void lidarComEdicao(int idAnotacao, String novoTexto) {
        try {
            servicoAnotacao.editarTextoAnotacao(idAnotacao, novoTexto);
        } catch (Exception e) {
            System.err.println("CONTROLLER ANOTAÇÃO: Erro - " + e.getMessage());
        }
    }

    public void lidarComAssociacao(int idAnotacao, ElementoMusical elemento)   {
        try {
        servicoAnotacao.associarAnotacao(idAnotacao, elemento);
        } catch (Exception e) {
            System.err.println("CONTROLLER ANOTAÇÃO: Erro ao associar anotação - " + e.getMessage());
        }
    }

    public void lidarComExclusao(int idAnotacao) {
        try {
            servicoAnotacao.excluirAnotacao(idAnotacao);
        } catch (Exception e) {
            System.err.println("CONTROLLER ANOTAÇÃO: Erro - " + e.getMessage());
        }
    }
    
    public Optional<Anotacao> lidarComBuscaPorId(int idAnotacao) {
        try {
            return servicoAnotacao.buscarPorId(idAnotacao);
        } catch (Exception e) {
            System.err.println("CONTROLLER ANOTAÇÃO: Erro ao buscar anotação - " + e.getMessage());
            return Optional.empty();
        }
    }
}