package controller;

import model.ElementoMusical;
import model.Nota;
import model.Progressao;
import service.ServicoAudio;
import service.ServicoBusca;

public class ControladorAudio {

    private final ServicoAudio servicoAudio;
    private final ServicoBusca servicoBusca;

    public ControladorAudio(ServicoAudio servicoAudio, ServicoBusca servicoBusca) {
        this.servicoAudio = servicoAudio;
        this.servicoBusca = servicoBusca;
    }

    public void lidarComTocarElemento(ElementoMusical elemento) {
        if(elemento == null) return;
        try {
            servicoAudio.tocarElementoMusical(elemento);
        } catch (RuntimeException e) {
            System.err.println("CONTROLLER AUDIO: Erro ao tentar tocar elemento: " + e.getMessage());
        }
    }
    
    public void tocarNota(Nota nota) {
        if (nota == null) {
            System.err.println("CONTROLLER AUDIO: Tentativa de reproduzir uma nota nula.");
            return;
        }
        servicoAudio.tocarNota(nota);
    }
    
    public void lidarComTocarProgressao(Progressao progressao) {
        if (progressao == null) {
            System.err.println("CONTROLLER AUDIO: Tentativa de reproduzir uma progressão nula.");
            return;
        }
        servicoAudio.tocarProgressao(progressao);
    }
}