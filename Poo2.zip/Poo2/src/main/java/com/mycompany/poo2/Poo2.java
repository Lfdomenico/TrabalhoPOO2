package com.mycompany.poo2;

import controller.*;
import repository.*;
import service.*;
import view.MenuPrincipalView;
import javax.swing.SwingUtilities;

public class Poo2 {

    public static void main(String[] args) {
        System.out.println("--- INICIALIZANDO SISTEMA DE TEORIA MUSICAL ---");

        try {
            System.out.println("Inicializando repositórios");
            EscalaRepositorio escalaRepo = new EscalaRepositorioMySQL();
            MusicaRepositorio musicaRepo = new MusicaRepositorioMySQL();
            NotaRepositorio notaRepo = new NotaRepositorioMySQL();
            FavoritosRepositorio favoritosRepo = new FavoritosRepositorioMySQL();
            
            AcordeRepositorio acordeRepo = new AcordeRepositorioMySQL(notaRepo);
            ProgressaoRepositorio progressaoRepo = new ProgressaoRepositorioMySQL(acordeRepo);
            AnotacaoRepositorio anotacaoRepo = new AnotacaoRepositorioMySQL(acordeRepo, escalaRepo);

            System.out.println("Inicializando serviços");
            ServicoMidi servicoMidi = new ServicoMidi();
            ServicoBusca servicoBusca = new ServicoBusca(acordeRepo, escalaRepo, musicaRepo, notaRepo, progressaoRepo);
            ServicoAudio servicoAudio = new ServicoAudio(servicoBusca);
            ServicoAnotacao servicoAnotacao = new ServicoAnotacao(anotacaoRepo, servicoBusca);
            ServicoProgressao servicoProgressao = new ServicoProgressao(progressaoRepo, acordeRepo);
            ServicoFavoritos servicoFavoritos = new ServicoFavoritos(favoritosRepo, servicoBusca);
            
            System.out.println("Inicializando controladores");
            ControladorAnotacao ctrlAnotacao = new ControladorAnotacao(servicoAnotacao, servicoBusca);
            ControladorAudio ctrlAudio = new ControladorAudio(servicoAudio, servicoBusca);
            ControladorBusca ctrlBusca = new ControladorBusca(servicoBusca);
            ControladorFavoritos ctrlFavoritos = new ControladorFavoritos(servicoFavoritos, servicoBusca);
            ControladorMidi ctrlMidi = new ControladorMidi(servicoMidi, servicoAudio);
            ControladorProgressao ctrlProgressao = new ControladorProgressao(servicoProgressao);
            ControladorVisualizacao ctrlVisualizacao = new ControladorVisualizacao(servicoBusca, servicoAnotacao);

            System.out.println("Iniciando interface gráfica");
            SwingUtilities.invokeLater(() -> {
                MenuPrincipalView menuPrincipal = new MenuPrincipalView();
                menuPrincipal.setControladores(ctrlAnotacao, ctrlAudio, ctrlBusca, ctrlFavoritos, ctrlMidi, ctrlProgressao, ctrlVisualizacao);

                menuPrincipal.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                        System.out.println("Janela principal fechada.");
                        servicoAudio.fechar();
                        servicoMidi.close();
                    }
                });

                menuPrincipal.setVisible(true);
            });

        } catch (Exception e) {
            System.err.println("\n!!! OCORREU UM ERRO NA INICIALIZAÇÃO DA APLICAÇÃO !!!");
            System.err.println("Verifique a conexão com o banco de dados e as dependências.");
            System.err.println("Mensagem: " + e.getMessage());
            e.printStackTrace();
        }
    }
}