package view;

import javax.swing.ImageIcon;
import controller.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import model.Escala;
import repository.AcordeRepositorio;
import repository.AcordeRepositorioMySQL;

public class EMEscalaView extends javax.swing.JPanel {

    private ControladorBusca ctrlBusca;
    private ControladorAudio ctrlAudio;
    private ControladorAnotacao ctrlAnotacao;
    private ControladorVisualizacao ctrlVisualizacao;
    private ControladorFavoritos ctrlFavoritos;
    
    private Escala escalaAtual;

    public EMEscalaView() {
        initComponents();
        limparDisplay();
    }
    
    public void setControladores(ControladorBusca ctrlBusca, ControladorAudio ctrlAudio, ControladorFavoritos ctrlFavoritos, ControladorVisualizacao ctrlVisualizacao, ControladorAnotacao ctrlAnotacao) {
        this.ctrlBusca = ctrlBusca;
        this.ctrlAudio = ctrlAudio;
        this.ctrlFavoritos = ctrlFavoritos;
        this.ctrlVisualizacao = ctrlVisualizacao;
        this.ctrlAnotacao = ctrlAnotacao;
    }
    
    private void limparDisplay() {
        this.escalaAtual = null;
        txtEscala.setText("Escala"); 
        txtBuscaEscala.setText("");
        textAreaInfoAdicional.setText("Busque por uma escala para ver suas informações.");
        chkFavorito.setSelected(false);
        chkFavorito.setEnabled(false);
        lblImagem.setIcon(new ImageIcon(getClass().getResource("/images/escalaMaior.png")));
    }
    
    private void atualizarDisplayEscala(Escala escala) {
        this.escalaAtual = escala;

        if (escala == null) {
            limparDisplay();
            return;
        }

        txtEscala.setText(escala.getNome() + " " + escala.getTipo());

        chkFavorito.setEnabled(true);
        if (ctrlFavoritos != null) {
            chkFavorito.setSelected(ctrlFavoritos.ehFavorito(escala));
        }
        
        StringBuilder info = new StringBuilder();
        info.append("Nome da Tônica: ").append(escala.getNome()).append("\n");
        info.append("Tipo de Escala: ").append(escala.getTipo()).append("\n");
        info.append("Estrutura (Notas): ").append(escala.getEstrutura()).append("\n");
        info.append("ID no Banco: ").append(escala.getId());

        textAreaInfoAdicional.setText(info.toString());

        if ("Maior".equalsIgnoreCase(escala.getTipo())) {
            lblImagem.setIcon(new ImageIcon(getClass().getResource("/images/escalaMaior.png")));
        } else if ("Menor".equalsIgnoreCase(escala.getTipo())) {
            lblImagem.setIcon(new ImageIcon(getClass().getResource("/images/escalaMenor.png")));
        } else {
            lblImagem.setIcon(null);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardAcorde = new javax.swing.JPanel();
        lblImagem = new javax.swing.JLabel();
        btnAnotacoes = new javax.swing.JButton();
        btnReproduzir = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        textAreaInfoAdicional = new javax.swing.JTextArea();
        btnMaiorMenor = new javax.swing.JButton();
        txtEscala = new javax.swing.JLabel();
        chkFavorito = new javax.swing.JCheckBox();
        btnBuscar = new javax.swing.JButton();
        txtBuscaEscala = new javax.swing.JTextField();

        lblImagem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/escalaMaior.png"))); // NOI18N

        btnAnotacoes.setText("Anotações");
        btnAnotacoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnotacoesActionPerformed(evt);
            }
        });

        btnReproduzir.setText("Reproduzir");
        btnReproduzir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReproduzirActionPerformed(evt);
            }
        });

        textAreaInfoAdicional.setColumns(20);
        textAreaInfoAdicional.setRows(5);
        jScrollPane2.setViewportView(textAreaInfoAdicional);

        btnMaiorMenor.setText("Maior/Menor");
        btnMaiorMenor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMaiorMenorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardAcordeLayout = new javax.swing.GroupLayout(cardAcorde);
        cardAcorde.setLayout(cardAcordeLayout);
        cardAcordeLayout.setHorizontalGroup(
            cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAcordeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardAcordeLayout.createSequentialGroup()
                        .addComponent(btnMaiorMenor)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAnotacoes)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnReproduzir))
                    .addGroup(cardAcordeLayout.createSequentialGroup()
                        .addComponent(lblImagem, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        cardAcordeLayout.setVerticalGroup(
            cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAcordeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(lblImagem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 20, Short.MAX_VALUE)
                .addGroup(cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAnotacoes)
                    .addComponent(btnReproduzir)
                    .addComponent(btnMaiorMenor))
                .addGap(14, 14, 14))
        );

        txtEscala.setText("ESCALA");

        chkFavorito.setText("★");
        chkFavorito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkFavoritoActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(txtEscala)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtBuscaEscala, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBuscar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chkFavorito)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cardAcorde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtEscala, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(chkFavorito)
                        .addComponent(btnBuscar)
                        .addComponent(txtBuscaEscala, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cardAcorde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void chkFavoritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkFavoritoActionPerformed
        if (escalaAtual == null) {
            chkFavorito.setSelected(false);
            return;
        }
        ctrlFavoritos.lidarComToggleFavorito(escalaAtual);

        final boolean estadoCorretoNoBanco = ctrlFavoritos.ehFavorito(escalaAtual);
        SwingUtilities.invokeLater(() -> {
            chkFavorito.setSelected(estadoCorretoNoBanco);
        });
    }//GEN-LAST:event_chkFavoritoActionPerformed

    private void btnAnotacoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnotacoesActionPerformed
        if (this.ctrlAnotacao == null) {
            JOptionPane.showMessageDialog(this, "Funcionalidade de anotações indisponível.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        AnotacaoDialog dialog = new AnotacaoDialog(
            (java.awt.Frame) javax.swing.SwingUtilities.getWindowAncestor(this),
            this.ctrlAnotacao,
            this.escalaAtual
        );

        dialog.setVisible(true);
    }//GEN-LAST:event_btnAnotacoesActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String nomeBusca = txtBuscaEscala.getText().trim();
        if (nomeBusca.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, digite o nome da escala (ex: C, Dm, G).");
            return;
        }

        Map<String, String> filtros = new HashMap<>();
        filtros.put("tipo", "escala");
        filtros.put("nome", nomeBusca);
        
        List<?> resultados = ctrlBusca.realizarBusca(filtros);
        
        if (resultados != null && !resultados.isEmpty()) {
            Escala escalaEncontrada = (Escala) resultados.get(0);
            atualizarDisplayEscala(escalaEncontrada);
        } else {
            JOptionPane.showMessageDialog(this, "Escala '" + nomeBusca + "' não encontrada no banco de dados.");
            limparDisplay();
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnReproduzirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReproduzirActionPerformed
        if (escalaAtual == null) {
            return;
        }
        ctrlAudio.lidarComTocarElemento(escalaAtual);
    }//GEN-LAST:event_btnReproduzirActionPerformed

    private void btnMaiorMenorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaiorMenorActionPerformed
        if (escalaAtual == null) {
            JOptionPane.showMessageDialog(this, "Por favor, busque uma escala primeiro para poder trocá-la.", "Ação Inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Optional<Escala> novaEscalaOpt = ctrlBusca.lidarComTrocaDeTipoDeEscala(escalaAtual);

        if (novaEscalaOpt.isPresent()) {
            atualizarDisplayEscala(novaEscalaOpt.get());
            JOptionPane.showMessageDialog(this, "Escala trocada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String tipoAlvo = "Maior".equalsIgnoreCase(escalaAtual.getTipo()) ? "Menor" : "Maior";
            JOptionPane.showMessageDialog(this, "Não foi possível encontrar a escala '" + escalaAtual.getNome() + " " + tipoAlvo + "' no banco de dados.", "Não Encontrado", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnMaiorMenorActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnotacoes;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnMaiorMenor;
    private javax.swing.JButton btnReproduzir;
    private javax.swing.JPanel cardAcorde;
    private javax.swing.JCheckBox chkFavorito;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblImagem;
    private javax.swing.JTextArea textAreaInfoAdicional;
    private javax.swing.JTextField txtBuscaEscala;
    private javax.swing.JLabel txtEscala;
    // End of variables declaration//GEN-END:variables
}
