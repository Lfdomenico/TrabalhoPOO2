package view;

import controller.ControladorAudio;
import controller.ControladorBusca;
import controller.ControladorProgressao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import model.Progressao;

import javax.swing.*;
import java.util.List;
import java.util.Map;
import javax.swing.filechooser.FileNameExtensionFilter;
import model.Acorde;

public class ProgressaoView extends JPanel {
    
    private ControladorProgressao controladorProgressao;
    private ControladorBusca controladorBusca;
    private ControladorAudio controladorAudio;

    private Progressao progressaoAtual;
    
    private int currentProgressaoId = -1;

    public ProgressaoView() {
        initComponents();
        
        btnGrpTipo.add(rdBtnMaior);
        btnGrpTipo.add(rdBtnMenor);
        
        this.progressaoAtual = null;
        
        conectarListeners();
        atualizarDisplay();

        txtProgressao.setEditable(false);
    }
    
    public void setControladores(ControladorProgressao ctrlP, ControladorBusca ctrlB, ControladorAudio ctrlA) {
        this.controladorProgressao = ctrlP;
        this.controladorBusca = ctrlB;
        this.controladorAudio = ctrlA;
    }
    
    private void acaoAdicionarAcorde(ActionEvent evt) {
        if (this.progressaoAtual == null) {
            JOptionPane.showMessageDialog(this, "Por favor, crie ou busque uma progressão primeiro.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String nomeTonica = ((JButton) evt.getSource()).getText();
        String tipoQualidade = rdBtnMaior.isSelected() ? "Maior" : "Menor";
        
        System.out.println("VIEW: Intenção: Adicionar o acorde '" + nomeTonica + " " + tipoQualidade + "'");
        
        Map<String, String> filtros = Map.of("tipo", "acorde", "nome", nomeTonica, "tipoAcorde", tipoQualidade);
        List<?> resultados = controladorBusca.realizarBusca(filtros);
        
        if (resultados.isEmpty() || !(resultados.get(0) instanceof Acorde)) {
            JOptionPane.showMessageDialog(this, "Acorde '" + nomeTonica + " " + tipoQualidade + "' não encontrado no banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Acorde acordeEncontrado = (Acorde) resultados.get(0);
        this.progressaoAtual = controladorProgressao.lidarComAdicaoAcorde(progressaoAtual.getId(), acordeEncontrado.getId());
        
        atualizarDisplay();
    }
    
    private void atualizarDisplay() {
        if (progressaoAtual != null) {
            String info = progressaoAtual.getInfoComplementar();
            txtProgressao.setText(info.isEmpty() ? "(Vazio)" : info);
        } else {
            txtProgressao.setText("Nenhuma progressão carregada. Crie ou busque uma.");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGrpTipo = new javax.swing.ButtonGroup();
        btnExcluir = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtProgressao = new javax.swing.JTextArea();
        btnImportar = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();
        btnReproduzirSom = new javax.swing.JButton();
        btnCriar = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 5), new java.awt.Dimension(0, 5), new java.awt.Dimension(32767, 5));
        btnC = new javax.swing.JButton();
        btnD = new javax.swing.JButton();
        btnE = new javax.swing.JButton();
        btnF = new javax.swing.JButton();
        btnG = new javax.swing.JButton();
        btnA = new javax.swing.JButton();
        btnB = new javax.swing.JButton();
        rdBtnMaior = new javax.swing.JRadioButton();
        rdBtnMenor = new javax.swing.JRadioButton();
        btnRemoverAcorde = new javax.swing.JButton();

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        txtProgressao.setColumns(20);
        txtProgressao.setRows(5);
        jScrollPane1.setViewportView(txtProgressao);

        btnImportar.setText("Importar");
        btnImportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportarActionPerformed(evt);
            }
        });

        btnExportar.setText("Exportar");
        btnExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportarActionPerformed(evt);
            }
        });

        btnReproduzirSom.setText("Reproduzir som");
        btnReproduzirSom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReproduzirSomActionPerformed(evt);
            }
        });

        btnCriar.setText("Criar");
        btnCriar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCriarActionPerformed(evt);
            }
        });

        btnC.setText("C");

        btnD.setText("D");

        btnE.setText("E");

        btnF.setText("F");

        btnG.setText("G");

        btnA.setText("A");

        btnB.setText("B");

        rdBtnMaior.setSelected(true);
        rdBtnMaior.setText("Maior");

        rdBtnMenor.setText("Menor");

        btnRemoverAcorde.setText("Remover Acorde");
        btnRemoverAcorde.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverAcordeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(129, 129, 129))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnRemoverAcorde)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnReproduzirSom))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnC, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnE, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnF, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnA, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnG, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnB, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnD, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCriar)
                    .addComponent(btnExcluir)
                    .addComponent(btnBuscar)
                    .addComponent(btnSalvar)
                    .addComponent(rdBtnMaior)
                    .addComponent(rdBtnMenor)
                    .addComponent(btnExportar)
                    .addComponent(btnImportar))
                .addContainerGap(92, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnReproduzirSom)
                    .addComponent(btnRemoverAcorde))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnCriar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExportar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnImportar)
                        .addGap(49, 49, 49)
                        .addComponent(rdBtnMenor)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdBtnMaior)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnC)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnD)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnF)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnG)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addComponent(btnB)))
                .addGap(18, 18, 18)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String termoBusca = JOptionPane.showInputDialog(this, "Digite o nome da progressão para buscar:");
        if (termoBusca == null || termoBusca.trim().isEmpty()) {
            return;
        }

        Map<String, String> filtros = Map.of("tipo", "progressao", "nome", termoBusca);
        List<?> resultados = this.controladorBusca.realizarBusca(filtros);

        if (resultados.isEmpty() || !(resultados.get(0) instanceof Progressao)) {
            this.progressaoAtual = null;
            this.currentProgressaoId = -1;
            atualizarDisplay();
            JOptionPane.showMessageDialog(this, "Nenhuma progressão encontrada com o nome '" + termoBusca + "'.");
        } else {
            Progressao progressaoEncontrada = (Progressao) resultados.get(0);
            this.progressaoAtual = progressaoEncontrada;
            this.currentProgressaoId = progressaoEncontrada.getId();
            atualizarDisplay();

            JOptionPane.showMessageDialog(this, "Progressão '" + progressaoEncontrada.getNome() + "' carregada.");
            if (resultados.size() > 1) {
                JOptionPane.showMessageDialog(this, "Múltiplas progressões encontradas. A primeira foi carregada.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportarActionPerformed
         if (currentProgressaoId != -1) {
            JOptionPane.showMessageDialog(this, "A progressão foi exportada com sucesso!\nO arquivo \'exportado.txt\' foi criado na pasta raiz do projeto.","Exportação Concluída",JOptionPane.INFORMATION_MESSAGE);
            controladorProgressao.lidarComExportacaoParaArquivo(currentProgressaoId, "exportado.txt");
        }
    }//GEN-LAST:event_btnExportarActionPerformed

    private void btnImportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportarActionPerformed
        JFileChooser seletorDeArquivo = new JFileChooser();
        seletorDeArquivo.setDialogTitle("Importar Progressão de Arquivo .txt");
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Arquivos de Texto (*.txt)", "txt");
        seletorDeArquivo.setFileFilter(filtro);
        int resultado = seletorDeArquivo.showOpenDialog(this);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File arquivoSelecionado = seletorDeArquivo.getSelectedFile();
            String caminhoDoArquivo = arquivoSelecionado.getAbsolutePath();
            String nomeNovaProgressao = JOptionPane.showInputDialog(this, "Digite o nome para a nova progressão importada:");

            if (nomeNovaProgressao == null || nomeNovaProgressao.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Importação cancelada ou nome inválido.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            System.out.println("VIEW: Enviando requisição de importação para o controller...");
            controladorProgressao.lidarComImportacaoDeArquivo(nomeNovaProgressao, caminhoDoArquivo);

            JOptionPane.showMessageDialog(this, "Tentativa de importação da progressão '" + nomeNovaProgressao + "' enviada.\nVerifique o console para o status.");

        } else {
            System.out.println("VIEW: Importação de arquivo cancelada pelo usuário.");
        }
    }//GEN-LAST:event_btnImportarActionPerformed

    private void btnReproduzirSomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReproduzirSomActionPerformed
        if (progressaoAtual == null) {
            JOptionPane.showMessageDialog(this, "Nenhuma progressão carregada para reproduzir.");
            return;
        }

        if (progressaoAtual.getAcordes().isEmpty()) {
            JOptionPane.showMessageDialog(this, "A progressão está vazia. Adicione acordes para reproduzir.");
            return;
        }

        System.out.println("VIEW: Enviando o objeto Progressao '" + progressaoAtual.getNome() + "' para o ControladorAudio.");
        controladorAudio.lidarComTocarProgressao(progressaoAtual);
    }//GEN-LAST:event_btnReproduzirSomActionPerformed

    private void btnCriarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCriarActionPerformed
        String nomeNovaProgressao = JOptionPane.showInputDialog(this, "Digite o nome para a nova progressão:");
        if (nomeNovaProgressao != null && !nomeNovaProgressao.trim().isEmpty()) {
            try {
                Progressao novaProgressao = controladorProgressao.lidarComCriacao(nomeNovaProgressao);
                if (novaProgressao != null) {
                    this.progressaoAtual = novaProgressao;
                    this.currentProgressaoId = novaProgressao.getId();
                    atualizarDisplay();
                    JOptionPane.showMessageDialog(this, "Progressão '" + nomeNovaProgressao + "' criada com sucesso! Já pode adicionar acordes.");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erro ao criar progressão: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnCriarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (currentProgressaoId == -1) {
            JOptionPane.showMessageDialog(this, "Nenhuma progressão carregada para excluir.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Tem certeza?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            controladorProgressao.lidarComExclusao(currentProgressaoId);
            JOptionPane.showMessageDialog(this, "Progressão excluída.");
            txtProgressao.setText("");
            currentProgressaoId = -1;
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
       if (progressaoAtual == null) {
        JOptionPane.showMessageDialog(this, "Nenhuma progressão carregada para salvar.");
        return;
    }
    try {
        this.progressaoAtual = controladorProgressao.lidarComSalvar(progressaoAtual);
        atualizarDisplay();
        JOptionPane.showMessageDialog(this, "Progressão '" + progressaoAtual.getNome() + "' salva com sucesso!");

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Erro ao salvar a progressão: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnRemoverAcordeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverAcordeActionPerformed
        if (progressaoAtual == null || progressaoAtual.getAcordes().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há acordes para remover.");
            return;
        }
        int ultimaPosicao = progressaoAtual.getAcordes().size() - 1;
        this.progressaoAtual = controladorProgressao.lidarComRemocaoDeAcorde(progressaoAtual.getId(), ultimaPosicao);
        atualizarDisplay();
    }//GEN-LAST:event_btnRemoverAcordeActionPerformed

    private void conectarListeners() {
        ActionListener listenerAdicionar = this::acaoAdicionarAcorde;
        
        btnC.addActionListener(listenerAdicionar);
        btnD.addActionListener(listenerAdicionar);
        btnE.addActionListener(listenerAdicionar);
        btnF.addActionListener(listenerAdicionar);
        btnG.addActionListener(listenerAdicionar);
        btnA.addActionListener(listenerAdicionar);
        btnB.addActionListener(listenerAdicionar);
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnA;
    private javax.swing.JButton btnB;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnC;
    private javax.swing.JButton btnCriar;
    private javax.swing.JButton btnD;
    private javax.swing.JButton btnE;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnF;
    private javax.swing.JButton btnG;
    private javax.swing.ButtonGroup btnGrpTipo;
    private javax.swing.JButton btnImportar;
    private javax.swing.JButton btnRemoverAcorde;
    private javax.swing.JButton btnReproduzirSom;
    private javax.swing.JButton btnSalvar;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdBtnMaior;
    private javax.swing.JRadioButton rdBtnMenor;
    private javax.swing.JTextArea txtProgressao;
    // End of variables declaration//GEN-END:variables
}
