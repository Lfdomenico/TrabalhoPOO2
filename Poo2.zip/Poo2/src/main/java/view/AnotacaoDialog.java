package view;

import controller.ControladorAnotacao;
import model.Anotacao;
import model.ElementoMusical;
import javax.swing.*;
import java.awt.*;
import java.util.Optional;

public class AnotacaoDialog extends JDialog {

    private final ControladorAnotacao ctrlAnotacao;
    private final ElementoMusical elementoAssociado;

    private JTextField txtId;
    private JTextArea txtAnotacao;
    private JButton btnCriar, btnBuscar, btnDeletar, btnSalvar;

    public AnotacaoDialog(Frame parent, ControladorAnotacao ctrlAnotacao, ElementoMusical elementoAssociado) {
        super(parent, "Gerenciar Anotação", true);
        this.ctrlAnotacao = ctrlAnotacao;
        this.elementoAssociado = elementoAssociado;

        setupUI();
        setupActions();
        
        if (elementoAssociado != null) {
            setTitle("Anotação para: " + elementoAssociado.getNome());
        }
    }

    private void setupUI() {
        setTitle("Gerenciar Anotação");
        setSize(400, 300);
        setLocationRelativeTo(getParent());
        setLayout(new BorderLayout(10, 10));
        JPanel panelTopo = new JPanel(new BorderLayout(5, 0));
        panelTopo.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        JLabel lblId = new JLabel("ID (Automático):");
        txtId = new JTextField();
        txtId.setEditable(false);
        txtId.setToolTipText("O ID é gerenciado pelo banco de dados após salvar.");
        panelTopo.add(lblId, BorderLayout.WEST);
        panelTopo.add(txtId, BorderLayout.CENTER);
        JPanel panelCentro = new JPanel(new BorderLayout());
        panelCentro.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        txtAnotacao = new JTextArea();
        txtAnotacao.setLineWrap(true);
        txtAnotacao.setWrapStyleWord(true);
        panelCentro.add(new JScrollPane(txtAnotacao), BorderLayout.CENTER);
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Centraliza os botões
        btnCriar = new JButton("Criar Nova");
        btnBuscar = new JButton("Buscar por ID");
        btnDeletar = new JButton("Deletar");
        btnSalvar = new JButton("Salvar");
        panelBotoes.add(btnCriar);
        panelBotoes.add(btnBuscar);
        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnDeletar);
        add(panelTopo, BorderLayout.NORTH);
        add(panelCentro, BorderLayout.CENTER);
        add(panelBotoes, BorderLayout.SOUTH);
    }
    
    private void setupActions() {
        btnCriar.addActionListener(e -> prepararNovaAnotacao());
        btnSalvar.addActionListener(e -> salvarAnotacao());
        btnBuscar.addActionListener(e -> buscarAnotacao());
        btnDeletar.addActionListener(e -> deletarAnotacao());
    }

    private void prepararNovaAnotacao() {
        txtId.setText("");
        txtAnotacao.setText("");
        txtAnotacao.requestFocus();
    }

    private void exibirAnotacao(Anotacao anotacao) {
        txtId.setText(String.valueOf(anotacao.getId()));
        txtAnotacao.setText(anotacao.getTexto());
    }

    private void salvarAnotacao() {
        String texto = txtAnotacao.getText().trim();
        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O texto da anotação não pode ser vazio.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String idStr = txtId.getText();
            Anotacao anotacaoSalva; // Variável para armazenar a anotação criada ou editada

            if (idStr.isEmpty()) { 
                System.out.println("DIALOG: Salvando uma NOVA anotação...");
                anotacaoSalva = ctrlAnotacao.lidarComCriacao(texto);

                if (anotacaoSalva == null) {
                    throw new RuntimeException("Falha ao criar anotação, controlador retornou nulo.");
                }

                if (elementoAssociado != null) {
                    System.out.println("DIALOG: Associando nova anotação ID " + anotacaoSalva.getId() + " ao elemento " + elementoAssociado.getNome());
                    ctrlAnotacao.lidarComAssociacao(anotacaoSalva.getId(), elementoAssociado);

                    JOptionPane.showMessageDialog(this, "Anotação criada e associada a '" + elementoAssociado.getNome() + "' com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this, "Anotação criada com sucesso! ID: " + anotacaoSalva.getId());
                }

                exibirAnotacao(anotacaoSalva);

            } else {
                System.out.println("DIALOG: Salvando uma anotação EXISTENTE...");
                int id = Integer.parseInt(idStr);
                ctrlAnotacao.lidarComEdicao(id, texto);
                JOptionPane.showMessageDialog(this, "Anotação atualizada com sucesso!");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao salvar: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void buscarAnotacao() {
        String input = JOptionPane.showInputDialog(this, "Digite o ID da anotação a ser buscada:");
        if (input == null || input.trim().isEmpty()) return;

        try {
            int id = Integer.parseInt(input.trim());
            Optional<Anotacao> resultado = ctrlAnotacao.lidarComBuscaPorId(id);

            if (resultado.isPresent()) {
                exibirAnotacao(resultado.get());
            } else {
                JOptionPane.showMessageDialog(this, "Anotação com ID " + id + " não encontrada.", "Não Encontrado", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID inválido. Por favor, digite um número.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletarAnotacao() {
        String idStr = txtId.getText();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Busque uma anotação primeiro para poder deletá-la.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja deletar esta anotação?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            int id = Integer.parseInt(idStr);
            ctrlAnotacao.lidarComExclusao(id);
            JOptionPane.showMessageDialog(this, "Anotação deletada com sucesso!");
            prepararNovaAnotacao();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}