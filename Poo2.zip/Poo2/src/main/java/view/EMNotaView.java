package view;

import controller.ControladorAudio;
import controller.ControladorBusca;
import model.Nota;
import javax.swing.*;
import java.awt.Color;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class EMNotaView extends JPanel {

    private ControladorBusca controladorBusca;
    private ControladorAudio controladorAudio;
    
    private Nota notaAtual;

    public EMNotaView() {
        initComponents();
        this.notaAtual = null;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        cardNota = new javax.swing.JPanel();
        btnBuscarNota = new javax.swing.JButton();
        txtTitulo = new javax.swing.JLabel();
        txtNota = new javax.swing.JLabel();
        textBuscarNota = new javax.swing.JTextField();
        areaInfo = new javax.swing.JTextArea();
        btnReproduzir = new javax.swing.JButton();
        btnTranspor = new javax.swing.JButton();

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        btnBuscarNota.setText("Buscar");
        btnBuscarNota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarNotaActionPerformed(evt);
            }
        });

        txtTitulo.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtTitulo.setText("NOTA");

        txtNota.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtNota.setText("C#");

        areaInfo.setColumns(20);
        areaInfo.setRows(5);

        btnReproduzir.setText("Reproduzir Som");
        btnReproduzir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReproduzirActionPerformed(evt);
            }
        });

        btnTranspor.setText("Transpor");
        btnTranspor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTransporActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardNotaLayout = new javax.swing.GroupLayout(cardNota);
        cardNota.setLayout(cardNotaLayout);
        cardNotaLayout.setHorizontalGroup(
            cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardNotaLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtTitulo)
                    .addComponent(txtNota))
                .addGap(28, 28, 28)
                .addGroup(cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardNotaLayout.createSequentialGroup()
                        .addComponent(areaInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnTranspor)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(cardNotaLayout.createSequentialGroup()
                        .addComponent(textBuscarNota, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnBuscarNota, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnReproduzir)))
                .addContainerGap())
        );
        cardNotaLayout.setVerticalGroup(
            cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardNotaLayout.createSequentialGroup()
                .addGroup(cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardNotaLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textBuscarNota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTitulo)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardNotaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnReproduzir)
                            .addComponent(btnBuscarNota))))
                .addGroup(cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardNotaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addGroup(cardNotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(areaInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnTranspor))
                        .addGap(24, 24, 24))
                    .addGroup(cardNotaLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(txtNota)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardNota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardNota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarNotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarNotaActionPerformed
        String nomeCompletoNota = textBuscarNota.getText().trim();

        if (nomeCompletoNota.isEmpty()) {
            atualizarTelaParaErro("Por favor, digite o nome completo da nota (ex: C4, C#5, Bb3).");
            return;
        }

        Map<String, String> filtros = Map.of("tipo", "nota","nomeCompleto", nomeCompletoNota);
        List<?> resultados = this.controladorBusca.realizarBusca(filtros);

        if (resultados.isEmpty()) {
            atualizarTelaParaErro("Nota '" + nomeCompletoNota + "' não encontrada no banco de dados.");
        } else {
            Object primeiroResultado = resultados.get(0);

            if (primeiroResultado instanceof Nota) {
                Nota notaEncontrada = (Nota) primeiroResultado;
                atualizarTelaComSucesso(notaEncontrada);
            } else {
                atualizarTelaParaErro("Resultado inesperado retornado pela busca.");
            }
        }
            if (resultados.isEmpty()) {
            atualizarTelaParaErro("Nota '" + nomeCompletoNota + "' não encontrada.");
        } else {
            if (resultados.get(0) instanceof Nota) {
                Nota notaEncontrada = (Nota) resultados.get(0);
                this.notaAtual = notaEncontrada;
                atualizarTelaComSucesso(notaAtual);
            } else {
                atualizarTelaParaErro("Resultado inesperado retornado.");
            }
        }
    }//GEN-LAST:event_btnBuscarNotaActionPerformed

    private void btnReproduzirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReproduzirActionPerformed
        if (notaAtual == null) {
            JOptionPane.showMessageDialog(this, "Por favor, busque uma nota primeiro.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        System.out.println("VIEW: Enviando nota '" + notaAtual.getNomeCompleto() + "' para reprodução.");
        controladorAudio.tocarNota(notaAtual); 
    }//GEN-LAST:event_btnReproduzirActionPerformed

    private void btnTransporActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTransporActionPerformed
        if (notaAtual == null) {
            JOptionPane.showMessageDialog(this, "Por favor, busque uma nota primeiro.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String intervaloStr = JOptionPane.showInputDialog(this, "Digite o intervalo de semitons (ex: 2 para subir um tom, -1 para descer um semitom):");

        if (intervaloStr == null || intervaloStr.trim().isEmpty()) {
            return;
        }

        try {
            int intervalo = Integer.parseInt(intervaloStr);
            Nota notaTransposta = notaAtual.transpor(intervalo);
            this.notaAtual = notaTransposta;
            atualizarTelaComSucesso(notaAtual);

            JOptionPane.showMessageDialog(this, "Nota transposta para: " + notaTransposta.getNomeCompleto());

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, digite um número inteiro válido.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Erro na transposição: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnTransporActionPerformed

    private void atualizarTelaComSucesso(Nota nota) {
        if (notaAtual == null) return;
        txtNota.setText(nota.getNome() + (nota.getAcidente() != null ? nota.getAcidente() : ""));

        areaInfo.setText("Nota Encontrada:\nID: " + notaAtual.getId() + "\nNome Completo: " + notaAtual.getNomeCompleto() + "\nValor MIDI: " + notaAtual.getValorMidi() + "\nOitava: " + notaAtual.getOitava()+ "\nValorMidi: " + notaAtual.getValorMidi());
        areaInfo.setForeground(Color.BLACK);
    }

    private void atualizarTelaParaErro(String mensagem) {
        this.notaAtual = null;
        txtNota.setText("?");
        areaInfo.setText(mensagem);
        areaInfo.setForeground(Color.RED);
    }
    
    public void setControladores(ControladorBusca controlador, ControladorAudio controladorAudio) {
        this.controladorAudio = controladorAudio;
        this.controladorBusca = controlador;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaInfo;
    private javax.swing.JButton btnBuscarNota;
    private javax.swing.JButton btnReproduzir;
    private javax.swing.JButton btnTranspor;
    private javax.swing.JPanel cardNota;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField textBuscarNota;
    private javax.swing.JLabel txtNota;
    private javax.swing.JLabel txtTitulo;
    // End of variables declaration//GEN-END:variables
}
