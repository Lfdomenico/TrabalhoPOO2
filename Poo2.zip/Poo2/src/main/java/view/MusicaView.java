package view;

import controller.ControladorAudio;
import controller.ControladorBusca;
import model.Musica;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;

public class MusicaView extends javax.swing.JPanel {

    private ControladorBusca controladorBusca;

    public MusicaView() {
        initComponents();
        
        lblTitulo.setText("Título:");
        lblArtista.setText("Artista:");
        lblTonica.setText("Tônica:");
        lblAno.setText("Ano:");
    }
    
    public void setControladores(ControladorBusca controlador) {
        this.controladorBusca = controlador;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtBuscaMusica = new javax.swing.JTextField();
        btnBuscarMusica = new javax.swing.JButton();
        lblTitulo = new javax.swing.JLabel();
        lblArtista = new javax.swing.JLabel();
        lblTonica = new javax.swing.JLabel();
        lblBusca = new javax.swing.JLabel();
        lblAno = new javax.swing.JLabel();

        txtBuscaMusica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscaMusicaActionPerformed(evt);
            }
        });

        btnBuscarMusica.setText("Buscar");
        btnBuscarMusica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarMusicaActionPerformed(evt);
            }
        });

        lblTitulo.setText("Título");

        lblArtista.setText("Artista");

        lblTonica.setText("Tônica");

        lblBusca.setText("Buscar música");

        lblAno.setText("Ano");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAno)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblBusca)
                        .addGap(25, 25, 25)
                        .addComponent(txtBuscaMusica, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscarMusica))
                    .addComponent(lblArtista)
                    .addComponent(lblTitulo)
                    .addComponent(lblTonica))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBuscaMusica, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarMusica)
                    .addComponent(lblBusca))
                .addGap(35, 35, 35)
                .addComponent(lblTitulo)
                .addGap(30, 30, 30)
                .addComponent(lblArtista)
                .addGap(35, 35, 35)
                .addComponent(lblTonica)
                .addGap(28, 28, 28)
                .addComponent(lblAno)
                .addContainerGap(22, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscaMusicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscaMusicaActionPerformed
        btnBuscarMusicaActionPerformed(evt);
    }//GEN-LAST:event_txtBuscaMusicaActionPerformed

    private void btnBuscarMusicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarMusicaActionPerformed
        String query = txtBuscaMusica.getText().trim();
        if (query.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, digite um título ou artista para buscar.");
            return;
        }
        
        if (controladorBusca == null) {
            JOptionPane.showMessageDialog(this, "Erro: O controlador de busca não foi inicializado.", "Erro Interno", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            java.util.Map<String, String> filtros = new java.util.HashMap<>();
            filtros.put("tipo", "musica");
            filtros.put("query", query);
            
            List<?> resultadoBruto = controladorBusca.realizarBusca(filtros);
            
            if (resultadoBruto != null && !resultadoBruto.isEmpty() && resultadoBruto.get(0) instanceof Musica) {
                List<Musica> musicasEncontradas = (List<Musica>) resultadoBruto;
                
                Musica primeiraMusica = musicasEncontradas.get(0);
                
                lblTitulo.setText("Título: " + primeiraMusica.getTitulo());
                lblArtista.setText("Artista: " + primeiraMusica.getArtista());
                lblAno.setText("Ano: " + primeiraMusica.getAno());
                lblTonica.setText("Tônica: " + primeiraMusica.getTonica());
                
                if (primeiraMusica.getAcordes() != null && !primeiraMusica.getAcordes().isEmpty()) {
                    String acordesStr = primeiraMusica.getAcordes().stream().map(acorde -> acorde.getNome()).collect(Collectors.joining(", "));
                }

                if (musicasEncontradas.size() > 1) {
                    JOptionPane.showMessageDialog(this, "Múltiplas músicas encontradas. Exibindo a primeira.");
                }

            } else {
                lblTitulo.setText("Título: Não encontrada.");
                lblArtista.setText("Artista: Não encontrada.");
                lblTonica.setText("Tônica: N/A.");
                lblAno.setText("Ano: N/A.");
                JOptionPane.showMessageDialog(this, "Nenhuma música encontrada para '" + query + "'.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar música: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            lblTitulo.setText("Título: Erro.");
            lblArtista.setText("Artista: Erro.");
            lblTonica.setText("Tônica: Erro.");
            lblAno.setText("Ano: Erro.");
        }
    }//GEN-LAST:event_btnBuscarMusicaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarMusica;
    private javax.swing.JLabel lblAno;
    private javax.swing.JLabel lblArtista;
    private javax.swing.JLabel lblBusca;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblTonica;
    private javax.swing.JTextField txtBuscaMusica;
    // End of variables declaration//GEN-END:variables
}
