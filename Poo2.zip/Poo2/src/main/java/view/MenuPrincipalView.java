package view;

import controller.*;
import java.awt.CardLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

public class MenuPrincipalView extends JFrame { 
    private ControladorProgressao ctrlProgressao;
    private ControladorBusca ctrlBusca;
    private ControladorAudio ctrlAudio;
    private ControladorVisualizacao ctrlVisualizacao;
    private ControladorMidi ctrlMidi;
    private ControladorFavoritos ctrlFavoritos;
    private ControladorAnotacao ctrlAnotacao;
    
    public MenuPrincipalView() {
        
        initComponents();
        
        setLocationRelativeTo(null);
    }
    
    private void configurarPaineisFilhos() {
        if (cardProgressao instanceof ProgressaoView) {
            ((ProgressaoView) cardProgressao).setControladores(this.ctrlProgressao, this.ctrlBusca, this.ctrlAudio);
        }
        if (cardNota instanceof EMNotaView) {
            ((EMNotaView) cardNota).setControladores(this.ctrlBusca, this.ctrlAudio);
        }
        if (cardTeclado instanceof TecladoView) {
             ((TecladoView) cardTeclado).setControladores(this.ctrlAudio, this.ctrlMidi);
        }
        if (cardMusica instanceof MusicaView){
            ((MusicaView) cardMusica).setControladores(this.ctrlBusca);
        }
        if (cardAcorde instanceof EMAcordeView) {
            ((EMAcordeView) cardAcorde).setControladores(this.ctrlBusca, this.ctrlAudio, this.ctrlFavoritos, this.ctrlVisualizacao, this.ctrlAnotacao);
        }
        if (cardEscala instanceof EMEscalaView) {
            ((EMEscalaView) cardEscala).setControladores(this.ctrlBusca, this.ctrlAudio, this.ctrlFavoritos, this.ctrlVisualizacao, this.ctrlAnotacao);
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painelCentro = new javax.swing.JPanel();
        cardMenuPrincipal = new javax.swing.JPanel();
        cardProgressao = new ProgressaoView();
        cardTeclado = new view.TecladoView();
        cardMusica = new view.MusicaView();
        cardAcorde = new EMAcordeView();
        cardEscala = new EMEscalaView();
        cardNota = new view.EMNotaView();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuElemento = new javax.swing.JMenu();
        Acorde = new javax.swing.JMenuItem();
        Escala = new javax.swing.JMenuItem();
        Nota = new javax.swing.JMenuItem();
        menuMusica = new javax.swing.JMenu();
        abrirMusica = new javax.swing.JMenuItem();
        menuProgressao = new javax.swing.JMenu();
        abrirProgressao = new javax.swing.JMenuItem();
        menuTeclado = new javax.swing.JMenu();
        abrirTeclado = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        painelCentro.setLayout(new java.awt.CardLayout());

        cardMenuPrincipal.setMaximumSize(new java.awt.Dimension(10000, 10000));
        painelCentro.add(cardMenuPrincipal, "cardMenuPrincipal");
        painelCentro.add(cardProgressao, "cardProgressao");
        painelCentro.add(cardTeclado, "cardTeclado");
        painelCentro.add(cardMusica, "cardMusica");

        cardAcorde.setMaximumSize(new java.awt.Dimension(10000, 10000));
        painelCentro.add(cardAcorde, "cardAcorde");

        cardEscala.setMaximumSize(new java.awt.Dimension(10000, 10000));
        painelCentro.add(cardEscala, "cardEscala");

        cardNota.setMaximumSize(new java.awt.Dimension(10000, 10000));
        painelCentro.add(cardNota, "cardNota");

        menuElemento.setText("Elemento Musical");

        Acorde.setText("Acorde");
        Acorde.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcordeActionPerformed(evt);
            }
        });
        menuElemento.add(Acorde);

        Escala.setText("Escala");
        Escala.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EscalaActionPerformed(evt);
            }
        });
        menuElemento.add(Escala);

        Nota.setText("Nota");
        Nota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NotaActionPerformed(evt);
            }
        });
        menuElemento.add(Nota);

        jMenuBar1.add(menuElemento);

        menuMusica.setText("Musica");
        menuMusica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuMusicaActionPerformed(evt);
            }
        });

        abrirMusica.setText("Abrir Musica");
        abrirMusica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirMusicaActionPerformed(evt);
            }
        });
        menuMusica.add(abrirMusica);

        jMenuBar1.add(menuMusica);

        menuProgressao.setText("Progressao");
        menuProgressao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuProgressaoActionPerformed(evt);
            }
        });

        abrirProgressao.setText("Abrir Progressao");
        abrirProgressao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirProgressaoActionPerformed(evt);
            }
        });
        menuProgressao.add(abrirProgressao);

        jMenuBar1.add(menuProgressao);

        menuTeclado.setText("Teclado");
        menuTeclado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuTecladoActionPerformed(evt);
            }
        });

        abrirTeclado.setText("Abrir Teclado");
        abrirTeclado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirTecladoActionPerformed(evt);
            }
        });
        menuTeclado.add(abrirTeclado);

        jMenuBar1.add(menuTeclado);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelCentro, javax.swing.GroupLayout.PREFERRED_SIZE, 1000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelCentro, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AcordeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AcordeActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardAcorde");
    }//GEN-LAST:event_AcordeActionPerformed

    private void menuProgressaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuProgressaoActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardProgressao");
    }//GEN-LAST:event_menuProgressaoActionPerformed

    private void menuMusicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuMusicaActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardMusica");
    }//GEN-LAST:event_menuMusicaActionPerformed

    private void menuTecladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuTecladoActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardTeclado");
    }//GEN-LAST:event_menuTecladoActionPerformed

    private void EscalaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EscalaActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardEscala");
    }//GEN-LAST:event_EscalaActionPerformed

    private void NotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NotaActionPerformed
        System.out.println("--- Menu 'Nota' clicado ---");
        System.out.println("Conteúdo do painelCentro ANTES de 'show':");

        for (java.awt.Component comp : painelCentro.getComponents()) {
            System.out.println("-> Componente encontrado: " + comp.getClass().getName());
        }

        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardNota");

        System.out.println("Comando 'show(painelCentro, \"cardNota\")' foi executado.");
    }//GEN-LAST:event_NotaActionPerformed

    private void abrirProgressaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirProgressaoActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardProgressao");
    }//GEN-LAST:event_abrirProgressaoActionPerformed

    private void abrirTecladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirTecladoActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardTeclado");
    }//GEN-LAST:event_abrirTecladoActionPerformed

    private void abrirMusicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirMusicaActionPerformed
        CardLayout cl = (CardLayout) painelCentro.getLayout();
        cl.show(painelCentro, "cardMusica");
    }//GEN-LAST:event_abrirMusicaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Acorde;
    private javax.swing.JMenuItem Escala;
    private javax.swing.JMenuItem Nota;
    private javax.swing.JMenuItem abrirMusica;
    private javax.swing.JMenuItem abrirProgressao;
    private javax.swing.JMenuItem abrirTeclado;
    private javax.swing.JPanel cardAcorde;
    private javax.swing.JPanel cardEscala;
    private javax.swing.JPanel cardMenuPrincipal;
    private javax.swing.JPanel cardMusica;
    private javax.swing.JPanel cardNota;
    private javax.swing.JPanel cardProgressao;
    private javax.swing.JPanel cardTeclado;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu menuElemento;
    private javax.swing.JMenu menuMusica;
    private javax.swing.JMenu menuProgressao;
    private javax.swing.JMenu menuTeclado;
    private javax.swing.JPanel painelCentro;
    // End of variables declaration//GEN-END:variables

    public void setControladores(ControladorAnotacao ctrlAnotacao, ControladorAudio ctrlAudio, ControladorBusca ctrlBusca, ControladorFavoritos ctrlFavoritos, ControladorMidi ctrlMidi, ControladorProgressao ctrlProgressao, ControladorVisualizacao ctrlVisualizacao) {
        this.ctrlAnotacao = ctrlAnotacao;
        this.ctrlAudio = ctrlAudio;
        this.ctrlBusca = ctrlBusca;
        this.ctrlFavoritos = ctrlFavoritos;
        this.ctrlMidi = ctrlMidi;
        this.ctrlProgressao = ctrlProgressao;
        this.ctrlVisualizacao = ctrlVisualizacao;
        
        configurarPaineisFilhos();
    }
}

