package view;

import controller.ControladorAnotacao;
import controller.ControladorAudio;
import controller.ControladorBusca;
import controller.ControladorFavoritos;
import controller.ControladorVisualizacao;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import model.Acorde;
import java.util.stream.Collectors;
import javax.swing.SwingUtilities;


public class EMAcordeView extends javax.swing.JPanel {

    private ControladorBusca ctrlBusca;
    private ControladorAudio ctrlAudio;
    private ControladorFavoritos ctrlFavoritos;
    private ControladorVisualizacao ctrlVisualizacao;
    private ControladorAnotacao ctrlAnotacao;
    
    private Acorde acordeAtual;
   
    public EMAcordeView() {
        initComponents();
        limparDisplay();
    }

    public void setControladores(ControladorBusca ctrlBusca, ControladorAudio ctrlAudio, ControladorFavoritos ctrlFavoritos, ControladorVisualizacao ctrlVisualizacao, ControladorAnotacao ctrlAnotacao) {
        this.ctrlBusca = ctrlBusca;
        this.ctrlAudio = ctrlAudio;
        this.ctrlFavoritos = ctrlFavoritos;
        this.ctrlVisualizacao = ctrlVisualizacao;
        this.ctrlAnotacao = ctrlAnotacao;
    }
    
    private void atualizarDisplayAcorde(Acorde acorde) {
        this.acordeAtual = acorde;

        if (acorde == null) {
            limparDisplay();
            return;
        }
        
        txtAcorde.setText(acorde.getNome() + " " + acorde.getTipo());
        chkFavorito.setEnabled(true);
        if (ctrlFavoritos != null) {
            chkFavorito.setSelected(ctrlFavoritos.ehFavorito(acorde));
        }

        StringBuilder info = new StringBuilder();
        info.append("Estado: Fundamental\n");
        info.append("Qualidade: ").append(acorde.getTipo()).append("\n");
        info.append("Tônica: ").append(acorde.getTonica() != null ? acorde.getTonica().getNomeCompleto() : "N/A").append("\n");

        String notasStr = acorde.getNotas().stream().map(n -> n.getNomeCompleto()).collect(java.util.stream.Collectors.joining(", "));
        info.append("Notas na formação: ").append(notasStr).append("\n");

        info.append("ID no Banco: ").append(acorde.getId());

        textAreaInfoAdicional.setText(info.toString());

        if ("Maior".equalsIgnoreCase(acorde.getTipo())) {
            lblImagemAcorde.setIcon(new ImageIcon(getClass().getResource("/images/acordeMaior.png")));
        } else if ("Menor".equalsIgnoreCase(acorde.getTipo())) {
            lblImagemAcorde.setIcon(new ImageIcon(getClass().getResource("/images/acordeMenor.png")));
        } else {
            lblImagemAcorde.setIcon(null);
        }
    }
    
    private void atualizarDisplayParaInversao(Acorde acordeInvertido, Acorde acordeOriginal) {
        txtAcorde.setText(acordeInvertido.getNome());

        StringBuilder info = new StringBuilder();
        info.append("Estado: Invertido").append("\n");
        info.append("Qualidade: ").append(acordeOriginal.getTipo()).append("\n");
        String notasStr = acordeInvertido.getNotas().stream().map(n -> n.getNomeCompleto()).collect(Collectors.joining(", "));
        info.append("Notas na ordem: ").append(notasStr);

        textAreaInfoAdicional.setText(info.toString());

        if ("Maior".equalsIgnoreCase(acordeOriginal.getTipo())) {
            lblImagemAcorde.setIcon(new ImageIcon(getClass().getResource("/images/acordeMaior.png")));
        } else if ("Menor".equalsIgnoreCase(acordeOriginal.getTipo())) {
            lblImagemAcorde.setIcon(new ImageIcon(getClass().getResource("/images/acordeMenor.png")));
        } else {
            lblImagemAcorde.setIcon(null);
        }

        chkFavorito.setSelected(false);
        chkFavorito.setEnabled(false);
    }
    
    private void limparDisplay() {
        acordeAtual = null;

        txtBuscaAcorde.setText("");
        txtAcorde.setText("Acorde");

        textAreaInfoAdicional.setText("Busque por um acorde para ver suas informações.");

        chkFavorito.setSelected(false);
        chkFavorito.setEnabled(true); 

        lblImagemAcorde.setIcon(new ImageIcon(getClass().getResource("/images/acordeMaior.png")));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardAcorde = new javax.swing.JPanel();
        btnBuscarAcorde = new javax.swing.JButton();
        lblImagemAcorde = new javax.swing.JLabel();
        chkFavorito = new javax.swing.JCheckBox();
        txtAcorde = new javax.swing.JLabel();
        btnInverter = new javax.swing.JButton();
        btnAnotacoes = new javax.swing.JButton();
        btnReproduzir = new javax.swing.JButton();
        txtBuscaAcorde = new javax.swing.JTextField();
        btnMaiormenor = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        textAreaInfoAdicional = new javax.swing.JTextArea();

        btnBuscarAcorde.setText("Buscar");
        btnBuscarAcorde.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarAcordeActionPerformed(evt);
            }
        });

        lblImagemAcorde.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/acordeMenor.png"))); // NOI18N

        chkFavorito.setText("★");
        chkFavorito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkFavoritoActionPerformed(evt);
            }
        });

        txtAcorde.setText("Acorde");

        btnInverter.setText("Inverter");
        btnInverter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInverterActionPerformed(evt);
            }
        });

        btnAnotacoes.setText("Anotações");
        btnAnotacoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnotacoesActionPerformed(evt);
            }
        });

        btnReproduzir.setText("Reproduzir");
        btnReproduzir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReproduzirActionPerformed(evt);
            }
        });

        btnMaiormenor.setText("Maior/Menor");
        btnMaiormenor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMaiormenorActionPerformed(evt);
            }
        });

        textAreaInfoAdicional.setColumns(20);
        textAreaInfoAdicional.setRows(5);
        jScrollPane2.setViewportView(textAreaInfoAdicional);

        javax.swing.GroupLayout cardAcordeLayout = new javax.swing.GroupLayout(cardAcorde);
        cardAcorde.setLayout(cardAcordeLayout);
        cardAcordeLayout.setHorizontalGroup(
            cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAcordeLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardAcordeLayout.createSequentialGroup()
                        .addComponent(txtAcorde)
                        .addGap(47, 47, 47)
                        .addComponent(txtBuscaAcorde, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscarAcorde)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chkFavorito))
                    .addGroup(cardAcordeLayout.createSequentialGroup()
                        .addComponent(btnMaiormenor)
                        .addGap(18, 18, 18)
                        .addComponent(btnAnotacoes)
                        .addGap(18, 18, 18)
                        .addComponent(btnReproduzir)
                        .addGap(18, 18, 18)
                        .addComponent(btnInverter))
                    .addGroup(cardAcordeLayout.createSequentialGroup()
                        .addComponent(lblImagemAcorde)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        cardAcordeLayout.setVerticalGroup(
            cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAcordeLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBuscarAcorde)
                    .addComponent(txtAcorde)
                    .addComponent(chkFavorito)
                    .addComponent(txtBuscaAcorde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(lblImagemAcorde, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(cardAcordeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMaiormenor)
                    .addComponent(btnAnotacoes)
                    .addComponent(btnReproduzir)
                    .addComponent(btnInverter))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardAcorde, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(cardAcorde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarAcordeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarAcordeActionPerformed
        String nomeAcorde = txtBuscaAcorde.getText().trim();
        if (nomeAcorde.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, digite o nome do acorde para buscar.");
            limparDisplay();
            return;
        }

        Map<String, String> filtros = new HashMap<>();
        filtros.put("tipo", "acorde");
        filtros.put("nomeContendo", nomeAcorde);

        List<?> resultados = ctrlBusca.realizarBusca(filtros);

        if (resultados != null && !resultados.isEmpty()) {
            Acorde acordeEncontrado = (Acorde) resultados.get(0);
            atualizarDisplayAcorde(acordeEncontrado);
        } else {
            JOptionPane.showMessageDialog(this, "Acorde '" + nomeAcorde + "' não encontrado.");
            limparDisplay();
        }
    }//GEN-LAST:event_btnBuscarAcordeActionPerformed

    private void chkFavoritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkFavoritoActionPerformed
        if (acordeAtual == null) {
            chkFavorito.setSelected(false);
            return;
        }
        ctrlFavoritos.lidarComToggleFavorito(acordeAtual);

        final boolean estadoCorretoNoBanco = ctrlFavoritos.ehFavorito(acordeAtual);
        SwingUtilities.invokeLater(() -> {
            chkFavorito.setSelected(estadoCorretoNoBanco);
        });
    }//GEN-LAST:event_chkFavoritoActionPerformed

    private void btnAnotacoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnotacoesActionPerformed
        if (this.ctrlAnotacao == null) {
        JOptionPane.showMessageDialog(this, "Funcionalidade de anotações indisponível.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    AnotacaoDialog dialog = new AnotacaoDialog(
        (java.awt.Frame) SwingUtilities.getWindowAncestor(this),
        this.ctrlAnotacao,
        this.acordeAtual
    );
    dialog.setVisible(true);
    }//GEN-LAST:event_btnAnotacoesActionPerformed

    private void btnReproduzirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReproduzirActionPerformed
        if (acordeAtual == null) {
            return;
        }
        ctrlAudio.lidarComTocarElemento(acordeAtual);
    }//GEN-LAST:event_btnReproduzirActionPerformed

    private void btnInverterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInverterActionPerformed
        if (acordeAtual == null) {
            JOptionPane.showMessageDialog(this, "Por favor, busque um acorde primeiro para invertê-lo.", "Ação Inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String input = JOptionPane.showInputDialog(
            this, 
            "Digite o grau da inversão (ex: 1 para primeira, 2 para segunda):", 
            "Inverter Acorde", 
            JOptionPane.QUESTION_MESSAGE
        );

        if (input == null) {
            return;
        }

        try {
            int grauInversao = Integer.parseInt(input.trim());

            if (grauInversao < 0) {
                JOptionPane.showMessageDialog(this, "O grau da inversão não pode ser negativo.", "Entrada Inválida", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (grauInversao == 0) {
                atualizarDisplayAcorde(this.acordeAtual);
                return;
            }

            Acorde acordeInvertido = ctrlVisualizacao.lidarComInversao(acordeAtual, grauInversao);

            atualizarDisplayParaInversao(acordeInvertido, this.acordeAtual);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Entrada inválida. Por favor, digite um número inteiro.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnInverterActionPerformed

    private void btnMaiormenorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaiormenorActionPerformed
        if (acordeAtual == null) {
            JOptionPane.showMessageDialog(this, "Por favor, busque um acorde primeiro para poder trocá-lo.", "Ação Inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Optional<Acorde> novoAcordeOpt = ctrlBusca.lidarComTrocaDeTipoDeAcorde(acordeAtual);

        if (novoAcordeOpt.isPresent()) {
            atualizarDisplayAcorde(novoAcordeOpt.get());

            JOptionPane.showMessageDialog(this, "Acorde trocado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String tipoAlvo = "Maior".equalsIgnoreCase(acordeAtual.getTipo()) ? "Menor" : "Maior";
            JOptionPane.showMessageDialog(this, "Não foi possível encontrar o acorde '" + acordeAtual.getNome() + " " + tipoAlvo + "' no banco de dados.", "Não Encontrado", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnMaiormenorActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnotacoes;
    private javax.swing.JButton btnBuscarAcorde;
    private javax.swing.JButton btnInverter;
    private javax.swing.JButton btnMaiormenor;
    private javax.swing.JButton btnReproduzir;
    private javax.swing.JPanel cardAcorde;
    private javax.swing.JCheckBox chkFavorito;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblImagemAcorde;
    private javax.swing.JTextArea textAreaInfoAdicional;
    private javax.swing.JLabel txtAcorde;
    private javax.swing.JTextField txtBuscaAcorde;
    // End of variables declaration//GEN-END:variables
}
