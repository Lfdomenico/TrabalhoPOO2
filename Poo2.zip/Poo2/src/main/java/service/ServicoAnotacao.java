package service;

import model.Anotacao;
import model.ElementoMusical;
import repository.AnotacaoRepositorio;
import java.util.List;
import java.util.Optional;

public class ServicoAnotacao {

    private final AnotacaoRepositorio anotacaoRepository;
    private final ServicoBusca servicoBusca;

    public ServicoAnotacao(AnotacaoRepositorio anotacaoRepository, ServicoBusca servicoBusca) {
        this.anotacaoRepository = anotacaoRepository;
        this.servicoBusca = servicoBusca;
    }

    public Anotacao criarAnotacao(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("O texto da anotação não pode ser vazio.");
        }
        Anotacao novaAnotacao = new Anotacao(texto, null);
        return anotacaoRepository.save(novaAnotacao);
    }


    public Anotacao associarAnotacao(int idAnotacao, ElementoMusical elementoParaAssociar) {
        Anotacao anotacao = anotacaoRepository.findById(idAnotacao).orElseThrow(() -> new RuntimeException("Anotação não encontrada com o ID: " + idAnotacao));
        anotacao.associarElemento(elementoParaAssociar);

        return anotacaoRepository.save(anotacao);
    }

    public List<Anotacao> buscarAnotacoesPorEntidade(int idElemento) {
        return anotacaoRepository.findByElementoId(idElemento);
    }

    public List<Anotacao> buscarTodasAnotacoes() {
        return anotacaoRepository.findAll();
    }
   
    public Anotacao editarTextoAnotacao(int idAnotacao, String novoTexto) {
        Anotacao anotacaoParaEditar = anotacaoRepository.findById(idAnotacao).orElseThrow(() -> new RuntimeException("Anotação não encontrada!"));

        anotacaoParaEditar.setTexto(novoTexto);
        Anotacao anotacaoAtualizada = anotacaoRepository.save(anotacaoParaEditar);

        return anotacaoAtualizada;
    }
    
    public void excluirAnotacao(int idAnotacao) {
        boolean existe = anotacaoRepository.findById(idAnotacao).isPresent();
        
        if (!existe) {
            throw new RuntimeException("Não é possível excluir, anotação com ID " + idAnotacao + " não foi encontrada.");
        }
        
        anotacaoRepository.deleteById(idAnotacao);
    }
    
    public Optional<Anotacao> buscarPorId(int idAnotacao) {
        return anotacaoRepository.findById(idAnotacao);
    }
}