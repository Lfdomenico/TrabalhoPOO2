package service;

import model.ElementoMusical;
import repository.FavoritosRepositorio;
import java.util.ArrayList;
import java.util.List;

public class ServicoFavoritos {

    private final FavoritosRepositorio favoritosRepo;
    private final ServicoBusca servicoBusca;

    public ServicoFavoritos(FavoritosRepositorio favoritosRepo, ServicoBusca servicoBusca) {
        this.favoritosRepo = favoritosRepo;
        this.servicoBusca = servicoBusca;
    }
    
    public void adicionarFavorito(ElementoMusical item) {
        favoritosRepo.adicionar(item);
    }

    public void removerFavorito(ElementoMusical item) {
        favoritosRepo.remover(item);
    }

    public boolean ehFavorito(ElementoMusical item) {
        return favoritosRepo.ehFavorito(item);
    }

    public List<ElementoMusical> listarFavoritos() {
        List<ElementoMusical> favoritos = new ArrayList<>();
        favoritosRepo.listarIdsDeAcordesFavoritos().stream().map(id -> servicoBusca.buscarAcorde(id)).forEach(favoritos::add);
        favoritosRepo.listarIdsDeEscalasFavoritas().stream().map(id -> servicoBusca.buscarEscala(id.intValue())).forEach(favoritos::add);
                
        return favoritos;
    }
}