package service;

import model.*;
import repository.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class ServicoBusca {
    private final AcordeRepositorio acordeRepo;
    private final EscalaRepositorio escalaRepo;
    private final MusicaRepositorio musicaRepo;
    private final NotaRepositorio notaRepo;
    private final ProgressaoRepositorio progressaoRepo;
    
    public ServicoBusca(AcordeRepositorio acordeRepo, EscalaRepositorio escalaRepo, 
                        MusicaRepositorio musicaRepo, NotaRepositorio notaRepo, 
                        ProgressaoRepositorio progressaoRepo) {
        this.acordeRepo = acordeRepo;
        this.escalaRepo = escalaRepo;
        this.musicaRepo = musicaRepo;
        this.notaRepo = notaRepo;
        this.progressaoRepo = progressaoRepo;
    }

    public ElementoMusical buscarEntidadeMusical(int id) {
        Optional<Acorde> acordeOpt = acordeRepo.findById(id);
        if (acordeOpt.isPresent()) {
            return acordeOpt.get();
        }

        Optional<Escala> escalaOpt = escalaRepo.findById(id);
        if (escalaOpt.isPresent()) {
            return escalaOpt.get();
        }
        throw new RuntimeException("Entidade Musical com ID " + id + " não encontrada em Acordes ou Escalas.");
    }

    public Acorde buscarAcorde(int id) {
        return acordeRepo.findById(id).orElseThrow(() -> new RuntimeException("Acorde não encontrado com o ID: " + id));
    }

    public List<Acorde> buscarAcordesPorNomeContendo(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return acordeRepo.findByNameContaining(nome);
    }
    
    public Optional<Acorde> buscarAcordePorNomeETipo(String nomeCifra, String tipo) {
        if (nomeCifra == null || nomeCifra.trim().isEmpty() || tipo == null || tipo.trim().isEmpty()) {
            return Optional.empty();
        }
        return acordeRepo.findByNomeAndTipo(nomeCifra, tipo);
    }

    public Escala buscarEscala(int id) {
        return escalaRepo.findById(id).orElseThrow(() -> new RuntimeException("Escala não encontrada com o ID: " + id));
    }
    
    public List<Escala> buscarEscalaPorNome(String nomeEscala) {
        if (nomeEscala == null || nomeEscala.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return escalaRepo.findByNome(nomeEscala).map(Collections::singletonList).orElse(Collections.emptyList());
    }

    public List<Musica> buscarMusica(String query) {
        if (query == null || query.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return musicaRepo.searchByTitleOrArtist(query);
    }
    
    public Nota buscarNota(int id) {
        return notaRepo.findById(id).orElseThrow(() -> new RuntimeException("Nota não encontrada com o ID: " + id));
    }
    
    public Optional<Nota> buscarNotaPorNomeCompleto(String nomeCompleto) {
        if (nomeCompleto == null || nomeCompleto.trim().isEmpty()) {
            return Optional.empty();
        }
        return notaRepo.findByNomeCompleto(nomeCompleto);
    }
    
    public List<Progressao> buscarProgressoesPorNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return progressaoRepo.findAllByNome(nome);
    }
    
    public Optional<Musica> buscarMusicaPorId(int id) {
        return musicaRepo.findById(id);
    }

    public List<Musica> listarTodasMusicas() {
        return musicaRepo.findAll();
    }

    public Musica criarMusica(String titulo, String artista, int ano, String tonica) {
        if (titulo == null || titulo.trim().isEmpty() || artista == null || artista.trim().isEmpty()) {
            throw new IllegalArgumentException("Título e artista não podem ser vazios para criar uma música.");
        }
        Musica novaMusica = new Musica(titulo, artista, ano, tonica);
        return musicaRepo.save(novaMusica);
    }

    public Musica atualizarMusica(int id, String novoTitulo, String novoArtista, int novoAno, String novaTonica) {
        Musica musica = musicaRepo.findById(id).orElseThrow(() -> new RuntimeException("Música com ID " + id + " não encontrada para atualização."));
        
        musica.setTitulo(novoTitulo);
        musica.setArtista(novoArtista);
        musica.setAno(novoAno);
        musica.setTonica(novaTonica);
        return musicaRepo.save(musica);
    }

    public void removerMusica(int id) {
        musicaRepo.deleteById(id);
    }
    
    public Optional<Escala> buscarEscalaPorNomeETipo(String nome, String tipo) {
        if (nome == null || nome.trim().isEmpty() || tipo == null || tipo.trim().isEmpty()) {
            return Optional.empty();
        }
        return escalaRepo.findByNomeAndTipo(nome, tipo);
    }
}