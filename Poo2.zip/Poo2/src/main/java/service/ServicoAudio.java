package service;

import model.Acorde;
import model.ElementoMusical;
import model.Escala;
import model.Nota;
import model.Progressao;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Synthesizer;

public class ServicoAudio {

    private final Synthesizer synthesizer;
    private final MidiChannel midiChannel;
    private final ServicoBusca servicoBusca;

    private static final int VELOCIDADE_PADRAO = 750;
    private static final int DURACAO_ACORDE_MS = 2000;
    private static final int DURACAO_NOTA_ESCALA_MS = 1000;

    public ServicoAudio(ServicoBusca servicoBusca) {
        this.servicoBusca = servicoBusca;
        try {
            this.synthesizer = MidiSystem.getSynthesizer();
            this.synthesizer.open();
            this.midiChannel = this.synthesizer.getChannels()[0];
        } catch (MidiUnavailableException e) {
            throw new IllegalStateException("Não foi possível inicializar o serviço de áudio.", e);
        }
    }

    public void tocarElementoMusical(ElementoMusical elemento) {
        if (elemento instanceof Acorde) {
            tocarAcorde((Acorde) elemento);
        } else if (elemento instanceof Escala) {
            tocarEscala((Escala) elemento);
        }
    }

    private void tocarAcorde(Acorde acorde) {
        if (acorde == null || acorde.getNotas() == null || acorde.getNotas().isEmpty()) return;
        new Thread(() -> {
            try {
                for (Nota nota : acorde.getNotas()) {
                    midiChannel.noteOn(nota.getValorMidi(), VELOCIDADE_PADRAO);
                }
                Thread.sleep(DURACAO_ACORDE_MS);
                for (Nota nota : acorde.getNotas()) {
                    midiChannel.noteOff(nota.getValorMidi());
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }).start();
    }

    private void tocarEscala(Escala escala) {
        if (escala == null || escala.getEstrutura() == null || escala.getEstrutura().trim().isEmpty()) {
            System.err.println("Serviço de Áudio: Escala inválida ou sem estrutura para tocar.");
            return;
        }

        String[] nomesDasNotas = escala.getEstrutura().split("\\s*-\\s*");
        List<Nota> notasParaTocar = new ArrayList<>();

        final int OITAVA_PADRAO_PARA_REPRODUCAO = 4;

        System.out.println("Serviço de Áudio: Montando notas para a escala '" + escala.getNome() + "' na oitava " + OITAVA_PADRAO_PARA_REPRODUCAO);

        for (String nomeNota : nomesDasNotas) {
            String nomeCompletoComOitava = nomeNota + OITAVA_PADRAO_PARA_REPRODUCAO;

            Optional<Nota> notaOpt = servicoBusca.buscarNotaPorNomeCompleto(nomeCompletoComOitava);

            if (notaOpt.isPresent()) {
                notasParaTocar.add(notaOpt.get());
            } else {
                System.err.println("AVISO: A nota '" + nomeCompletoComOitava + "' não foi encontrada no banco e será ignorada na reprodução.");
            }
        }

        if (notasParaTocar.isEmpty()) {
            System.err.println("ERRO FATAL: Nenhuma nota válida foi encontrada para tocar na escala '" + escala.getNome() + "'. Verifique a estrutura da escala e o conteúdo da tabela de notas.");
            return;
        }

        new Thread(() -> {
            try {
                System.out.println("Tocando Escala: " + escala.getNome());
                for (Nota nota : notasParaTocar) {
                    midiChannel.noteOn(nota.getValorMidi(), VELOCIDADE_PADRAO);
                    Thread.sleep(DURACAO_NOTA_ESCALA_MS);
                    midiChannel.noteOff(nota.getValorMidi());
                }
                System.out.println("Reprodução da escala finalizada.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    public void tocarProgressao(Progressao progressao) {
        if (progressao == null || progressao.getAcordes() == null || progressao.getAcordes().isEmpty()) return;
        new Thread(() -> {
            try {
                for (var acorde : progressao.getAcordes()) {
                    tocarAcorde((Acorde) acorde);
                    Thread.sleep(200);
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }).start();
    }

    public void pressionarNota(Nota nota) {
        if (nota != null) {
            midiChannel.noteOn(nota.getValorMidi(), VELOCIDADE_PADRAO);
            System.out.println("AUDIO: Note ON -> " + nota.getNomeCompleto());
        }
    }

    public void soltarNota(Nota nota) {
        if (nota != null) {
            midiChannel.noteOff(nota.getValorMidi());
            System.out.println("AUDIO: Note OFF -> " + nota.getNomeCompleto());
        }
    }

    public void fechar() {
        if (synthesizer != null && synthesizer.isOpen()) {
            synthesizer.close();
        }
    }
    
    public void tocarNota(Nota nota) {
        if (nota == null) {
            return;
        }
        
        new Thread(() -> {
            try {
                System.out.println("AUDIO: Tocando nota individual -> " + nota.getNomeCompleto());
                pressionarNota(nota);
                Thread.sleep(VELOCIDADE_PADRAO);
                soltarNota(nota);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("A reprodução da nota foi interrompida.");
            }}).start();
    }
}